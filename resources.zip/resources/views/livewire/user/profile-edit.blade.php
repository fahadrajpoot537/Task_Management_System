<div>
    <!-- Header Section -->
    <div class="card mb-4">
        <div class="card-header bg-gradient-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2 class="mb-2 text-white fw-bold">
                        <i class="bi bi-person-gear me-3"></i>Edit Profile
                    </h2>
                    <p class="mb-0 text-white-50 fs-6">Update your personal information and profile settings</p>
                </div>
                <a href="{{ route('dashboard') }}" class="btn btn-light">
                    <i class="bi bi-arrow-left me-2"></i>Back to Dashboard
                </a>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Profile Information -->
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header bg-gradient-light">
                    <h5 class="mb-0 text-primary">
                        <i class="bi bi-info-circle me-2"></i>Personal Information
                    </h5>
                </div>
                <div class="card-body">
                    <form wire:submit="updateProfile">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label for="name" class="form-label fw-semibold">
                                    Full Name <span class="text-danger">*</span>
                                </label>
                                <input type="text" class="form-control @error('name') is-invalid @enderror" 
                                       id="name" wire:model="name" required>
                                @error('name')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-6">
                                <label for="email" class="form-label fw-semibold">
                                    Email Address <span class="text-danger">*</span>
                                </label>
                                <input type="email" class="form-control @error('email') is-invalid @enderror" 
                                       id="email" wire:model="email" required>
                                @error('email')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-6">
                                <label for="phone" class="form-label fw-semibold">
                                    <i class="bi bi-telephone me-2"></i>Phone Number
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <i class="bi bi-phone"></i>
                                    </span>
                                    <input type="tel" class="form-control @error('phone') is-invalid @enderror" 
                                           id="phone" wire:model="phone" placeholder="+1 (555) 123-4567"
                                           pattern="[0-9+\-\s\(\)]+" maxlength="20">
                                </div>
                                <div class="form-text">Enter your phone number with country code</div>
                                @error('phone')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-6">
                                <label for="role" class="form-label fw-semibold">Role</label>
                                <input type="text" class="form-control" value="{{ $user->role->name ?? 'No Role' }}" readonly>
                                <div class="form-text">Role cannot be changed here. Contact administrator.</div>
                            </div>
                            
                            <div class="col-12">
                                <label for="bio" class="form-label fw-semibold">Bio</label>
                                <textarea class="form-control @error('bio') is-invalid @enderror" 
                                          id="bio" wire:model="bio" rows="4" 
                                          placeholder="Tell us about yourself..."></textarea>
                                <div class="form-text">Maximum 500 characters</div>
                                @error('bio')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="d-flex justify-content-end gap-3 mt-4">
                            <a href="{{ route('dashboard') }}" class="btn btn-outline-secondary btn-lg">
                                <i class="bi bi-x-circle me-2"></i>Cancel
                            </a>
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="bi bi-check-circle me-2"></i>Update Profile
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Avatar Section -->
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header bg-gradient-light">
                    <h5 class="mb-0 text-primary">
                        <i class="bi bi-image me-2"></i>Profile Picture
                    </h5>
                </div>
                <div class="card-body text-center">
                    <!-- Current Avatar -->
                    <div class="mb-4 text-center">
                        @if($currentAvatar)
                            <div class="position-relative d-inline-block">
                                <img src="{{ Storage::url($currentAvatar) }}" alt="Profile Picture" 
                                     class="rounded-circle mb-3 shadow-lg" style="width: 150px; height: 150px; object-fit: cover; border: 4px solid #3b82f6;">
                                <div class="position-absolute top-0 end-0">
                                    <span class="badge bg-success rounded-pill">
                                        <i class="bi bi-check-circle"></i>
                                    </span>
                                </div>
                            </div>
                        @else
                            <div class="rounded-circle bg-gradient-primary text-white d-flex align-items-center justify-content-center mx-auto mb-3 shadow-lg" 
                                 style="width: 150px; height: 150px; font-size: 3rem; border: 4px solid #3b82f6;">
                                {{ substr($user->name, 0, 1) }}
                            </div>
                        @endif
                        <h6 class="text-muted">{{ $currentAvatar ? 'Current Profile Picture' : 'No Profile Picture' }}</h6>
                    </div>

                    <!-- Upload New Avatar -->
                    <div class="mb-3">
                        <label for="avatar" class="form-label fw-semibold">
                            <i class="bi bi-cloud-upload me-2"></i>Upload New Picture
                        </label>
                        <div class="upload-area border-2 border-dashed border-primary rounded p-4 text-center" 
                             style="background: rgba(59, 130, 246, 0.05);">
                            <input type="file" class="form-control @error('avatar') is-invalid @enderror" 
                                   id="avatar" wire:model="avatar" accept="image/*" 
                                   style="position: absolute; opacity: 0; width: 100%; height: 100%; cursor: pointer;">
                            <div class="upload-content">
                                <i class="bi bi-cloud-upload fs-1 text-primary mb-2"></i>
                                <p class="mb-2 text-primary fw-semibold">Click to upload or drag & drop</p>
                                <small class="text-muted">Max size: 2MB. Supported: JPG, PNG, GIF</small>
                            </div>
                        </div>
                        @error('avatar')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>

                    <!-- Preview New Avatar -->
                    @if($avatar)
                        <div class="mb-3">
                            <label class="form-label fw-semibold">
                                <i class="bi bi-eye me-2"></i>Preview
                            </label>
                            <div class="text-center">
                                <img src="{{ $avatar->temporaryUrl() }}" alt="Preview" 
                                     class="rounded-circle shadow" style="width: 120px; height: 120px; object-fit: cover; border: 3px solid #10b981;">
                                <div class="mt-2">
                                    <span class="badge bg-success">
                                        <i class="bi bi-check-circle me-1"></i>Ready to upload
                                    </span>
                                </div>
                            </div>
                        </div>
                    @endif

                    <!-- Action Buttons -->
                    <div class="d-grid gap-2">
                        @if($currentAvatar)
                            <button type="button" class="btn btn-outline-danger btn-sm" wire:click="removeAvatar"
                                    wire:confirm="Are you sure you want to remove your profile picture?">
                                <i class="bi bi-trash me-1"></i>Remove Picture
                            </button>
                        @endif
                        
                        @if($avatar)
                            <button type="button" class="btn btn-success btn-sm" wire:click="updateProfile">
                                <i class="bi bi-check-circle me-1"></i>Save New Picture
                            </button>
                        @endif
                    </div>
                </div>
            </div>

            <!-- Account Information -->
            <div class="card mt-4">
                <div class="card-header bg-gradient-light">
                    <h5 class="mb-0 text-primary">
                        <i class="bi bi-shield-check me-2"></i>Account Information
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-12">
                            <div class="d-flex justify-content-between align-items-center p-3 rounded" style="background-color: var(--bg-tertiary);">
                                <div>
                                    <div class="fw-semibold">Member Since</div>
                                    <small class="text-muted">{{ $user->created_at->format('M d, Y') }}</small>
                                </div>
                                <i class="bi bi-calendar text-primary fs-4"></i>
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="d-flex justify-content-between align-items-center p-3 rounded" style="background-color: var(--bg-tertiary);">
                                <div>
                                    <div class="fw-semibold">Last Updated</div>
                                    <small class="text-muted">{{ $user->updated_at->format('M d, Y') }}</small>
                                </div>
                                <i class="bi bi-clock text-primary fs-4"></i>
                            </div>
                        </div>
                        
                        @if($user->manager)
                            <div class="col-12">
                                <div class="d-flex justify-content-between align-items-center p-3 rounded" style="background-color: var(--bg-tertiary);">
                                    <div>
                                        <div class="fw-semibold">Manager</div>
                                        <small class="text-muted">{{ $user->manager->name }}</small>
                                    </div>
                                    <i class="bi bi-person-badge text-primary fs-4"></i>
                                </div>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Password Change Section -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-gradient-light">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0 text-primary">
                            <i class="bi bi-shield-lock me-2"></i>Change Password
                        </h5>
                        <button type="button" class="btn btn-outline-primary btn-sm" wire:click="togglePasswordForm">
                            <i class="bi bi-{{ $showPasswordForm ? 'eye-slash' : 'eye' }} me-1"></i>
                            {{ $showPasswordForm ? 'Hide' : 'Change Password' }}
                        </button>
                    </div>
                </div>
                @if($showPasswordForm)
                <div class="card-body">
                    <form wire:submit="changePassword" class="password-form">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label for="currentPassword" class="form-label fw-semibold">
                                    <i class="bi bi-key me-2"></i>Current Password <span class="text-danger">*</span>
                                </label>
                                <input type="password" class="form-control @error('currentPassword') is-invalid @enderror" 
                                       id="currentPassword" wire:model="currentPassword" required>
                                @error('currentPassword')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-4">
                                <label for="newPassword" class="form-label fw-semibold">
                                    <i class="bi bi-key-fill me-2"></i>New Password <span class="text-danger">*</span>
                                </label>
                                <input type="password" class="form-control @error('newPassword') is-invalid @enderror" 
                                       id="newPassword" wire:model="newPassword" required>
                                <div class="form-text">Minimum 8 characters</div>
                                @if($newPassword)
                                    <div class="password-strength mt-2">
                                        <div class="progress" style="height: 5px;">
                                            <div class="progress-bar" id="passwordStrength" role="progressbar" style="width: 0%"></div>
                                        </div>
                                        <small class="text-muted" id="passwordStrengthText">Password strength</small>
                                    </div>
                                @endif
                                @error('newPassword')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-4">
                                <label for="confirmPassword" class="form-label fw-semibold">
                                    <i class="bi bi-check-circle me-2"></i>Confirm Password <span class="text-danger">*</span>
                                </label>
                                <input type="password" class="form-control @error('confirmPassword') is-invalid @enderror" 
                                       id="confirmPassword" wire:model="confirmPassword" required>
                                @error('confirmPassword')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="d-flex justify-content-end gap-3 mt-4">
                            <button type="button" class="btn btn-outline-secondary" wire:click="togglePasswordForm">
                                <i class="bi bi-x-circle me-2"></i>Cancel
                            </button>
                            <button type="submit" class="btn btn-warning">
                                <i class="bi bi-shield-check me-2"></i>Change Password
                            </button>
                        </div>
                    </form>
                </div>
                @else
                <div class="card-body">
                    <div class="text-center py-4">
                        <i class="bi bi-shield-lock text-muted" style="font-size: 3rem;"></i>
                        <h6 class="text-muted mt-3">Password Security</h6>
                        <p class="text-muted mb-0">Click "Change Password" to update your account password</p>
                    </div>
                </div>
                @endif
            </div>
        </div>
    </div>

    <style>
        .bg-gradient-primary {
            background: linear-gradient(135deg, #3b82f6 0%, #2563eb 50%, #1d4ed8 100%);
        }
        
        .bg-gradient-light {
            background: linear-gradient(135deg, rgba(59, 130, 246, 0.05) 0%, rgba(59, 130, 246, 0.1) 100%);
            border-bottom: 1px solid rgba(59, 130, 246, 0.1);
        }
        
        .form-control {
            border-radius: 0.75rem;
            border: 2px solid rgba(59, 130, 246, 0.1);
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 0.2rem rgba(59, 130, 246, 0.25);
        }
        
        .btn-lg {
            padding: 0.75rem 2rem;
            font-size: 1rem;
            border-radius: 0.75rem;
            font-weight: 600;
        }
        
        .form-text {
            color: #2563eb;
            font-size: 0.875rem;
        }
        
        .form-label {
            color: #1e40af;
            font-size: 1rem;
        }
        
        .bg-light {
            background-color: var(--bg-tertiary) !important;
            border: 1px solid var(--border-color);
        }
        
        .upload-area {
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .upload-area:hover {
            background: rgba(59, 130, 246, 0.1) !important;
            border-color: #3b82f6 !important;
            transform: translateY(-2px);
        }
        
        .upload-area.dragover {
            background: rgba(59, 130, 246, 0.15) !important;
            border-color: #2563eb !important;
            transform: scale(1.02);
        }
        
        .input-group-text {
            background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
            color: white;
            border: 2px solid #3b82f6;
        }
        
        .form-control:focus + .input-group-text,
        .form-control:focus ~ .input-group-text {
            border-color: #3b82f6;
        }
        
        .badge {
            font-size: 0.75rem;
            padding: 0.5rem 0.75rem;
        }
        
        .shadow-lg {
            box-shadow: 0 10px 25px rgba(59, 130, 246, 0.15) !important;
        }
        
        .shadow {
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.1) !important;
        }
        
        /* Phone number formatting */
        .phone-input {
            font-family: 'Courier New', monospace;
            letter-spacing: 0.5px;
        }
        
        /* Password form styling */
        .password-form {
            background: linear-gradient(135deg, rgba(245, 158, 11, 0.05) 0%, rgba(245, 158, 11, 0.1) 100%);
            border: 1px solid rgba(245, 158, 11, 0.2);
            border-radius: 1rem;
            padding: 1.5rem;
        }
        
        .password-form .form-control {
            border: 2px solid rgba(245, 158, 11, 0.2);
        }
        
        .password-form .form-control:focus {
            border-color: #f59e0b;
            box-shadow: 0 0 0 0.2rem rgba(245, 158, 11, 0.25);
        }
        
        .btn-warning {
            background: linear-gradient(135deg, #f59e0b 0%, #f97316 100%);
            border: none;
            color: white;
            font-weight: 600;
        }
        
        .btn-warning:hover {
            background: linear-gradient(135deg, #f97316 0%, #ea580c 100%);
            transform: translateY(-1px);
        }
        
        /* Loading states */
        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        
        /* Success message styling */
        .alert-success {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1) 0%, rgba(16, 185, 129, 0.05) 100%);
            border: 1px solid rgba(16, 185, 129, 0.2);
            color: #065f46;
        }
        
        /* Error message styling */
        .alert-danger {
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.1) 0%, rgba(239, 68, 68, 0.05) 100%);
            border: 1px solid rgba(239, 68, 68, 0.2);
            color: #991b1b;
        }
        
        @media (max-width: 768px) {
            .card-header.bg-gradient-primary {
                padding: 1rem;
            }
            
            .card-header.bg-gradient-primary h2 {
                font-size: 1.5rem;
            }
            
            .btn-lg {
                padding: 0.75rem 1.5rem;
                font-size: 0.9rem;
            }
        }
    </style>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Password strength indicator
            const newPasswordInput = document.getElementById('newPassword');
            const confirmPasswordInput = document.getElementById('confirmPassword');
            const passwordStrength = document.getElementById('passwordStrength');
            const passwordStrengthText = document.getElementById('passwordStrengthText');
            
            if (newPasswordInput) {
                newPasswordInput.addEventListener('input', function() {
                    const password = this.value;
                    const strength = calculatePasswordStrength(password);
                    
                    if (passwordStrength && passwordStrengthText) {
                        passwordStrength.style.width = strength.percentage + '%';
                        passwordStrength.className = 'progress-bar ' + strength.class;
                        passwordStrengthText.textContent = strength.text;
                        passwordStrengthText.className = 'text-' + strength.textClass;
                    }
                });
            }
            
            // Password confirmation validation
            if (confirmPasswordInput) {
                confirmPasswordInput.addEventListener('input', function() {
                    const newPassword = newPasswordInput ? newPasswordInput.value : '';
                    const confirmPassword = this.value;
                    
                    if (confirmPassword && newPassword) {
                        if (confirmPassword === newPassword) {
                            this.classList.remove('is-invalid');
                            this.classList.add('is-valid');
                        } else {
                            this.classList.remove('is-valid');
                            this.classList.add('is-invalid');
                        }
                    } else {
                        this.classList.remove('is-valid', 'is-invalid');
                    }
                });
            }
            
            function calculatePasswordStrength(password) {
                let score = 0;
                let feedback = [];
                
                // Length check
                if (password.length >= 8) score += 1;
                else feedback.push('At least 8 characters');
                
                // Lowercase check
                if (/[a-z]/.test(password)) score += 1;
                else feedback.push('Lowercase letter');
                
                // Uppercase check
                if (/[A-Z]/.test(password)) score += 1;
                else feedback.push('Uppercase letter');
                
                // Number check
                if (/[0-9]/.test(password)) score += 1;
                else feedback.push('Number');
                
                // Special character check
                if (/[^A-Za-z0-9]/.test(password)) score += 1;
                else feedback.push('Special character');
                
                const percentage = (score / 5) * 100;
                
                if (score <= 2) {
                    return {
                        percentage: percentage,
                        class: 'bg-danger',
                        text: 'Weak - ' + feedback.join(', '),
                        textClass: 'danger'
                    };
                } else if (score <= 3) {
                    return {
                        percentage: percentage,
                        class: 'bg-warning',
                        text: 'Fair - ' + feedback.join(', '),
                        textClass: 'warning'
                    };
                } else if (score <= 4) {
                    return {
                        percentage: percentage,
                        class: 'bg-info',
                        text: 'Good - ' + feedback.join(', '),
                        textClass: 'info'
                    };
                } else {
                    return {
                        percentage: percentage,
                        class: 'bg-success',
                        text: 'Strong password!',
                        textClass: 'success'
                    };
                }
            }

            // Drag and drop functionality for avatar upload
            const uploadArea = document.querySelector('.upload-area');
            const fileInput = document.getElementById('avatar');
            
            if (uploadArea && fileInput) {
                // Prevent default drag behaviors
                ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                    uploadArea.addEventListener(eventName, preventDefaults, false);
                    document.body.addEventListener(eventName, preventDefaults, false);
                });

                // Highlight drop area when item is dragged over it
                ['dragenter', 'dragover'].forEach(eventName => {
                    uploadArea.addEventListener(eventName, highlight, false);
                });

                ['dragleave', 'drop'].forEach(eventName => {
                    uploadArea.addEventListener(eventName, unhighlight, false);
                });

                // Handle dropped files
                uploadArea.addEventListener('drop', handleDrop, false);

                function preventDefaults(e) {
                    e.preventDefault();
                    e.stopPropagation();
                }

                function highlight(e) {
                    uploadArea.classList.add('dragover');
                }

                function unhighlight(e) {
                    uploadArea.classList.remove('dragover');
                }

                function handleDrop(e) {
                    const dt = e.dataTransfer;
                    const files = dt.files;
                    
                    if (files.length > 0) {
                        fileInput.files = files;
                        // Trigger Livewire update
                        fileInput.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                }
            }

            // Show success/error messages
            @if(session('success'))
                showAlert('{{ session('success') }}', 'success');
            @endif

            @if(session('error'))
                showAlert('{{ session('error') }}', 'danger');
            @endif

            function showAlert(message, type) {
                const alertDiv = document.createElement('div');
                alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
                alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
                alertDiv.innerHTML = `
                    <i class="bi bi-${type === 'success' ? 'check-circle' : 'exclamation-triangle'} me-2"></i>
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                `;
                
                document.body.appendChild(alertDiv);
                
                // Auto remove after 5 seconds
                setTimeout(() => {
                    if (alertDiv.parentNode) {
                        alertDiv.remove();
                    }
                }, 5000);
            }
        });
    </script>
</div>
