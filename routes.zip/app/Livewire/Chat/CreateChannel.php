<?php

namespace App\Livewire\Chat;

use Livewire\Component;

class CreateChannel extends Component
{
    public function render()
    {
        return view('livewire.chat.create-channel');
    }
}
