<div>
    <div class="card">
        <div class="card-header">
            <h3 class="mb-0">
                <i class="bi bi-gear me-2"></i>Settings
            </h3>
            <p class="text-muted mb-0">Customize your application experience</p>
        </div>
        <div class="card-body">
            <!-- Theme Selection -->
            <div class="mb-5">
                <h5 class="mb-3">
                    <i class="bi bi-palette me-2"></i>Choose Your Theme
                </h5>
                <p class="text-muted mb-4">Select a theme that matches your style and preferences</p>
                
                <div class="row g-3">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $themeKey => $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="theme-card <?php echo e($currentTheme === $themeKey ? 'active' : ''); ?>" 
                                 wire:click="changeTheme('<?php echo e($themeKey); ?>')"
                                 style="cursor: pointer;">
                                <div class="theme-preview">
                                    <div class="theme-colors">
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $theme['colors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="color-swatch" style="background-color: <?php echo e($color); ?>"></div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                                <div class="theme-info">
                                    <h6 class="theme-name"><?php echo e($theme['name']); ?></h6>
                                    <p class="theme-description"><?php echo e($theme['description']); ?></p>
                                    <!--[if BLOCK]><![endif]--><?php if($currentTheme === $themeKey): ?>
                                        <span class="badge bg-primary">
                                            <i class="bi bi-check-circle me-1"></i>Active
                                        </span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>

            <!-- Font Family Selection -->
            <div class="mb-5">
                <h5 class="mb-3">
                    <i class="bi bi-type me-2"></i>Choose Your Font Style
                </h5>
                <p class="text-muted mb-4">Select a font that matches your reading preference</p>
                
                <div class="row g-3">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $fontFamilies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fontKey => $font): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="font-card <?php echo e($currentFontFamily === $fontKey ? 'active' : ''); ?>" 
                                 wire:click="changeFontFamily('<?php echo e($fontKey); ?>')"
                                 style="cursor: pointer;">
                                <div class="font-preview" style="font-family: <?php echo e($font['font']); ?>">
                                    <div class="font-sample">
                                        <h6 style="font-family: <?php echo e($font['font']); ?>">Aa Bb Cc</h6>
                                        <p style="font-family: <?php echo e($font['font']); ?>">Sample Text</p>
                                    </div>
                                </div>
                                <div class="font-info">
                                    <h6 class="font-name"><?php echo e($font['name']); ?></h6>
                                    <p class="font-description"><?php echo e($font['description']); ?></p>
                                    <!--[if BLOCK]><![endif]--><?php if($currentFontFamily === $fontKey): ?>
                                        <span class="badge bg-primary">
                                            <i class="bi bi-check-circle me-1"></i>Active
                                        </span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>

            <!-- Font Size Selection -->
            <div class="mb-5">
                <h5 class="mb-3">
                    <i class="bi bi-arrows-expand me-2"></i>Choose Your Font Size
                </h5>
                <p class="text-muted mb-4">Select a font size that's comfortable for reading</p>
                
                <div class="row g-3">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $fontSizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizeKey => $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-3">
                            <div class="font-size-card <?php echo e($currentFontSize === $sizeKey ? 'active' : ''); ?>" 
                                 wire:click="changeFontSize('<?php echo e($sizeKey); ?>')"
                                 style="cursor: pointer;">
                                <div class="font-size-preview" style="font-size: <?php echo e($size['size']); ?>">
                                    <div class="font-size-sample">
                                        <h6 style="font-size: <?php echo e($size['size']); ?>">Aa Bb Cc</h6>
                                        <p style="font-size: <?php echo e($size['size']); ?>">Sample Text</p>
                                    </div>
                                </div>
                                <div class="font-size-info">
                                    <h6 class="font-size-name"><?php echo e($size['name']); ?></h6>
                                    <p class="font-size-description"><?php echo e($size['description']); ?></p>
                                    <!--[if BLOCK]><![endif]--><?php if($currentFontSize === $sizeKey): ?>
                                        <span class="badge bg-primary">
                                            <i class="bi bi-check-circle me-1"></i>Active
                                        </span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>

            <!-- Current Settings Info -->
            <div class="alert alert-info">
                <h6 class="alert-heading">
                    <i class="bi bi-info-circle me-2"></i>Current Settings
                </h6>
                <p class="mb-1"><strong>Theme:</strong> <?php echo e($themes[$currentTheme]['name']); ?> - <?php echo e($themes[$currentTheme]['description']); ?></p>
                <p class="mb-1"><strong>Font:</strong> <?php echo e($fontFamilies[$currentFontFamily]['name']); ?> - <?php echo e($fontFamilies[$currentFontFamily]['description']); ?></p>
                <p class="mb-0"><strong>Size:</strong> <?php echo e($fontSizes[$currentFontSize]['name']); ?> - <?php echo e($fontSizes[$currentFontSize]['description']); ?></p>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\myapp\resources\views/livewire/settings.blade.php ENDPATH**/ ?>