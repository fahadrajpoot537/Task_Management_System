<?php

namespace App\Livewire;

use Livewire\Component;

class DynamicOptionsManager extends Component
{
    public function render()
    {
        return view('livewire.dynamic-options-manager');
    }
}
