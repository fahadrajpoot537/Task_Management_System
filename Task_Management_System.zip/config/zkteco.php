<?php

return [
    'ip' => '192.168.1.201',
    'port' => 4370
];
