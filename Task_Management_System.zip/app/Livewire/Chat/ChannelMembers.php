<?php

namespace App\Livewire\Chat;

use Livewire\Component;

class ChannelMembers extends Component
{
    public function render()
    {
        return view('livewire.chat.channel-members');
    }
}
