<?php

namespace App\Livewire\Admin;

use Livewire\Component;

class TaskStatusManager extends Component
{
    public function render()
    {
        return view('livewire.admin.task-status-manager');
    }
}
