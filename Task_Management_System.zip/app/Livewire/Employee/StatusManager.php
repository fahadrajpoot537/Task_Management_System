<?php

namespace App\Livewire\Employee;

use Livewire\Component;

class StatusManager extends Component
{
    public function render()
    {
        return view('livewire.employee.status-manager');
    }
}
