<?php

namespace App\Livewire\Attendance;

use Livewire\Component;

class UserAttendanceDetails extends Component
{
    public function render()
    {
        return view('livewire.attendance.user-attendance-details');
    }
}
