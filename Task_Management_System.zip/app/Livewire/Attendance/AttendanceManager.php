<?php

namespace App\Livewire\Attendance;

use Livewire\Component;

class AttendanceManager extends Component
{
    public function render()
    {
        return view('livewire.attendance.attendance-manager');
    }
}
