<div>
    <button class="<?php echo e($buttonClass); ?>" wire:click="toggleTheme" type="button" title="Switch Theme (<?php echo e(ucfirst($currentTheme)); ?>)">
        <i class="bi <?php echo e($currentTheme === 'dark' ? 'bi-moon' : ($currentTheme === 'light' ? 'bi-sun' : 'bi-palette')); ?>" id="theme-icon"></i>
    </button>
</div>
<?php /**PATH C:\xampp\htdocs\Task_Management_System\resources\views/livewire/theme-toggle.blade.php ENDPATH**/ ?>