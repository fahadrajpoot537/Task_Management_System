<?php

namespace App\Livewire\Chat;

use Livewire\Component;

class ChatWindow extends Component
{
    public function render()
    {
        return view('livewire.chat.chat-window');
    }
}
