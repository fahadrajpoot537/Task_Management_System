<?php

namespace App\Livewire\Project;

use App\Models\Project;
use App\Models\Task;
use Livewire\Component;
use Livewire\WithPagination;

class ProjectDetails extends Component
{
    use WithPagination;

    public Project $project;
    public $search = '';
    public $statusFilter = '';
    public $priorityFilter = '';

    protected $queryString = [
        'search' => ['except' => ''],
        'statusFilter' => ['except' => ''],
        'priorityFilter' => ['except' => ''],
    ];

    public function mount($projectId)
    {
        $this->project = Project::with(['createdBy', 'tasks.assignedTo', 'tasks.assignedBy'])
            ->findOrFail($projectId);
        
        // Check if user has permission to view this project
        $user = auth()->user();
        if (!$user->isSuperAdmin() && $this->project->created_by_user_id !== $user->id) {
            if ($user->isManager()) {
                $teamMemberIds = $user->teamMembers->pluck('id')->push($user->id);
                if (!$teamMemberIds->contains($this->project->created_by_user_id)) {
                    abort(403, 'You do not have permission to view this project.');
                }
            } else {
                abort(403, 'You do not have permission to view this project.');
            }
        }
    }

    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function updatingStatusFilter()
    {
        $this->resetPage();
    }

    public function updatingPriorityFilter()
    {
        $this->resetPage();
    }

    public function getTasksProperty()
    {
        $query = $this->project->tasks()
            ->with(['assignedTo', 'assignedBy'])
            ->when($this->search, function ($query) {
                $query->where('title', 'like', '%' . $this->search . '%')
                      ->orWhere('description', 'like', '%' . $this->search . '%');
            })
            ->when($this->statusFilter, function ($query) {
                $query->where('status', $this->statusFilter);
            })
            ->when($this->priorityFilter, function ($query) {
                $query->where('priority', $this->priorityFilter);
            });

        return $query->orderBy('created_at', 'desc')->paginate(10);
    }

    public function getProjectStatsProperty()
    {
        $totalTasks = $this->project->tasks()->count();
        $completedTasks = $this->project->tasks()->where('status', 'completed')->count();
        $inProgressTasks = $this->project->tasks()->where('status', 'in_progress')->count();
        $pendingTasks = $this->project->tasks()->where('status', 'pending')->count();
        $overdueTasks = $this->project->tasks()
            ->where('due_date', '<', now())
            ->where('status', '!=', 'completed')
            ->count();

        return [
            'total' => $totalTasks,
            'completed' => $completedTasks,
            'in_progress' => $inProgressTasks,
            'pending' => $pendingTasks,
            'overdue' => $overdueTasks,
            'progress_percentage' => $totalTasks > 0 ? round(($completedTasks / $totalTasks) * 100, 1) : 0,
        ];
    }

    public function render()
    {
        return view('livewire.project.project-details')
            ->layout('layouts.app');
    }
}
