<?php

namespace App\Livewire\Project;

use App\Models\Log;
use App\Models\Project;
use Livewire\Component;
use Livewire\WithPagination;

class ProjectIndex extends Component
{
    use WithPagination;

    public $search = '';
    public $sortField = 'created_at';
    public $sortDirection = 'desc';

    protected $queryString = [
        'search' => ['except' => ''],
        'sortField' => ['except' => 'created_at'],
        'sortDirection' => ['except' => 'desc'],
    ];

    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function sortBy($field)
    {
        if ($this->sortField === $field) {
            $this->sortDirection = $this->sortDirection === 'asc' ? 'desc' : 'asc';
        } else {
            $this->sortDirection = 'asc';
        }

        $this->sortField = $field;
    }

    public function deleteProject($projectId)
    {
        $project = Project::findOrFail($projectId);
        
        // Check if user can delete this project
        if (!auth()->user()->isSuperAdmin() && $project->created_by_user_id !== auth()->id()) {
            session()->flash('error', 'You do not have permission to delete this project.');
            return;
        }

        // Log the deletion
        Log::createLog(auth()->id(), 'delete_project', "Deleted project: {$project->title}");

        $project->delete();
        
        session()->flash('success', 'Project deleted successfully.');
    }

    public function getProjectsProperty()
    {
        $user = auth()->user();
        
        $query = Project::with(['createdBy', 'tasks'])
            ->when($this->search, function ($query) {
                $query->where('title', 'like', '%' . $this->search . '%')
                      ->orWhere('description', 'like', '%' . $this->search . '%');
            });

        if ($user->isSuperAdmin()) {
            // Super admin can see all projects
        } elseif ($user->isManager()) {
            $teamMemberIds = $user->teamMembers->pluck('id')->push($user->id);
            $query->whereIn('created_by_user_id', $teamMemberIds);
        } elseif ($user->isAdmin()) {
            // Admin can see all projects but cannot manage permissions
            // No additional filtering needed
        } else {
            // Employees can see projects they created and projects from their team
            $teamMemberIds = collect([$user->id]);
            if ($user->manager) {
                $teamMemberIds = $user->manager->teamMembers->pluck('id')->push($user->manager->id);
            }
            $query->whereIn('created_by_user_id', $teamMemberIds);
        }

        return $query->orderBy($this->sortField, $this->sortDirection)
                    ->paginate(10);
    }

    public function render()
    {
        return view('livewire.project.project-index')
            ->layout('layouts.app');
    }
}
