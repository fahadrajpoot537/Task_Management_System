<?php

namespace App\Livewire;

use Livewire\Component;

class TaskCategoryManager extends Component
{
    public function render()
    {
        return view('livewire.task-category-manager');
    }
}
