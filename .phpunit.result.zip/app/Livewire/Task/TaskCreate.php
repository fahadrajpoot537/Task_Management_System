<?php

namespace App\Livewire\Task;

use App\Mail\TaskAssigned;
use App\Models\Log;
use App\Models\Project;
use App\Models\Task;
use App\Models\User;
use App\Models\TaskStatus;
use App\Models\TaskPriority;
use App\Models\TaskCategory;
use Livewire\Component;
use Livewire\WithFileUploads;
use Illuminate\Support\Facades\Mail;

class TaskCreate extends Component
{
    use WithFileUploads;

    public $project_id = '';
    public $title = '';
    public $description = '';
    public $priority_id = '';
    public $category_id = '';
    public $status_id = '';
    public $duration = '';
    public $due_date = '';
    public $assigned_to_user_id = '';
    public $notes = '';
    public $attachments = [];

    // Add form properties
    public $showAddPriorityForm = false;
    public $showAddCategoryForm = false;
    public $showAddStatusForm = false;
    public $newPriorityName = '';
    public $newPriorityColor = 'secondary';
    public $newCategoryName = '';
    public $newCategoryIcon = 'bi-list-task';
    public $newCategoryColor = 'secondary';
    public $newStatusName = '';
    public $newStatusColor = 'secondary';
    public $newStatusIsDefault = false;

    protected $rules = [
        'project_id' => 'required|exists:projects,id',
        'title' => 'required|string|max:255',
        'description' => 'nullable|string',
        'priority_id' => 'required|exists:task_priorities,id',
        'category_id' => 'required|exists:task_categories,id',
        'status_id' => 'nullable|exists:task_statuses,id',
        'duration' => 'nullable|integer|min:1',
        'due_date' => 'nullable|date|after:today',
        'assigned_to_user_id' => 'required|exists:users,id',
        'notes' => 'nullable|string',
        'attachments.*' => 'nullable|file|max:10240', // 10MB max
    ];

    public function mount()
    {
        $user = auth()->user();
        
        // Set default assigned user based on role
        if ($user->isEmployee()) {
            $this->assigned_to_user_id = $user->id;
        }
    }

    public function createTask()
    {
        $this->validate();

        $task = Task::create([
            'project_id' => $this->project_id,
            'title' => $this->title,
            'description' => $this->description,
            'priority_id' => $this->priority_id,
            'category_id' => $this->category_id,
            'status_id' => $this->status_id ?: $this->getDefaultStatusId(),
            'duration' => $this->duration,
            'due_date' => $this->due_date,
            'assigned_to_user_id' => $this->assigned_to_user_id,
            'assigned_by_user_id' => auth()->id(),
            'notes' => $this->notes,
        ]);

        // Handle file uploads
        if ($this->attachments) {
            foreach ($this->attachments as $attachment) {
                $path = $attachment->store('attachments');
                
                $task->attachments()->create([
                    'file_path' => $path,
                    'file_name' => $attachment->getClientOriginalName(),
                    'uploaded_by_user_id' => auth()->id(),
                ]);
            }
        }

        // Log the creation
        Log::createLog(auth()->id(), 'create_task', "Created task: {$task->title}");

        // Send email notification to assigned user
        $assignedUser = User::find($this->assigned_to_user_id);
        Mail::to($assignedUser->email)->send(new TaskAssigned($task));

        // Send email notification to super admin
        $superAdmin = User::whereHas('role', function($query) {
            $query->where('name', 'super_admin');
        })->first();
        
        if ($superAdmin && $superAdmin->id !== auth()->id()) {
            Mail::to($superAdmin->email)->send(new TaskAssigned($task, 'New task created'));
        }

        session()->flash('success', 'Task created successfully.');

        return redirect()->route('tasks.index');
    }

    public function getProjectsProperty()
    {
        $user = auth()->user();
        
        if ($user->isSuperAdmin()) {
            return Project::all();
        } elseif ($user->isManager()) {
            $teamMemberIds = $user->teamMembers->pluck('id')->push($user->id);
            return Project::whereIn('created_by_user_id', $teamMemberIds)->get();
        } else {
            return Project::where('created_by_user_id', $user->id)->get();
        }
    }

    public function getAvailableUsersProperty()
    {
        $user = auth()->user();
        
        if ($user->isSuperAdmin()) {
            return User::all();
        } elseif ($user->isManager()) {
            return $user->teamMembers;
        } else {
            return collect([$user]);
        }
    }

    public function render()
    {
        return view('livewire.task.task-create')
            ->layout('layouts.app');
    }
}
