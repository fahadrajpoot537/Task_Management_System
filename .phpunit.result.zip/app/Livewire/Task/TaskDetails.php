<?php

namespace App\Livewire\Task;

use App\Models\Log;
use App\Models\Task;
use Livewire\Component;
use Livewire\WithFileUploads;

class TaskDetails extends Component
{
    use WithFileUploads;

    public Task $task;
    public $newNote = '';
    public $newAttachments = [];

    protected $rules = [
        'newNote' => 'nullable|string',
        'newAttachments.*' => 'nullable|file|max:10240', // 10MB max
    ];

    public function mount($taskId)
    {
        $this->task = Task::with(['project', 'assignedTo', 'assignedBy', 'attachments.uploadedBy'])
            ->findOrFail($taskId);
    }

    public function updateStatus($status)
    {
        // Check if user can update this task
        if (!auth()->user()->isSuperAdmin() && 
            $this->task->assigned_to_user_id !== auth()->id() && 
            $this->task->assigned_by_user_id !== auth()->id()) {
            session()->flash('error', 'You do not have permission to update this task.');
            return;
        }

        $oldStatus = $this->task->status;
        $this->task->update(['status' => $status]);

        // Log the status change
        Log::createLog(auth()->id(), 'update_task_status', 
            "Changed task '{$this->task->title}' status from {$oldStatus} to {$status}");

        session()->flash('success', 'Task status updated successfully.');
    }

    public function addNote()
    {
        $this->validate(['newNote' => 'required|string']);

        $currentNotes = $this->task->notes ? $this->task->notes . "\n\n" : '';
        $newNote = "[" . now()->format('Y-m-d H:i:s') . "] " . auth()->user()->name . ": " . $this->newNote;
        
        $this->task->update([
            'notes' => $currentNotes . $newNote
        ]);

        // Log the note addition
        Log::createLog(auth()->id(), 'add_task_note', 
            "Added note to task: {$this->task->title}");

        $this->newNote = '';
        session()->flash('success', 'Note added successfully.');
    }

    public function addAttachments()
    {
        $this->validate(['newAttachments.*' => 'required|file|max:10240']);

        foreach ($this->newAttachments as $attachment) {
            $path = $attachment->store('attachments');
            
            $this->task->attachments()->create([
                'file_path' => $path,
                'file_name' => $attachment->getClientOriginalName(),
                'uploaded_by_user_id' => auth()->id(),
            ]);
        }

        // Log the attachment addition
        Log::createLog(auth()->id(), 'add_task_attachment', 
            "Added attachments to task: {$this->task->title}");

        $this->newAttachments = [];
        $this->task->load('attachments.uploadedBy');
        session()->flash('success', 'Attachments uploaded successfully.');
    }

    public function deleteAttachment($attachmentId)
    {
        $attachment = $this->task->attachments()->findOrFail($attachmentId);
        
        // Check if user can delete this attachment
        if (!auth()->user()->isSuperAdmin() && 
            $attachment->uploaded_by_user_id !== auth()->id()) {
            session()->flash('error', 'You do not have permission to delete this attachment.');
            return;
        }

        // Delete file from storage
        if (file_exists(storage_path('app/' . $attachment->file_path))) {
            unlink(storage_path('app/' . $attachment->file_path));
        }

        // Log the deletion
        Log::createLog(auth()->id(), 'delete_task_attachment', 
            "Deleted attachment from task: {$this->task->title}");

        $attachment->delete();
        $this->task->load('attachments.uploadedBy');
        
        session()->flash('success', 'Attachment deleted successfully.');
    }

    public function render()
    {
        return view('livewire.task.task-details')
            ->layout('layouts.app');
    }
}
