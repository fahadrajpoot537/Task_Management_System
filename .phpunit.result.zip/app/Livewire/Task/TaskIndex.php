<?php

namespace App\Livewire\Task;

use App\Models\Log;
use App\Models\Task;
use Livewire\Component;
use Livewire\WithPagination;

class TaskIndex extends Component
{
    use WithPagination;

    public $search = '';
    public $statusFilter = '';
    public $priorityFilter = '';
    public $userFilter = '';
    public $sortField = 'created_at';
    public $sortDirection = 'desc';

    protected $queryString = [
        'search' => ['except' => ''],
        'statusFilter' => ['except' => ''],
        'priorityFilter' => ['except' => ''],
        'userFilter' => ['except' => ''],
        'sortField' => ['except' => 'created_at'],
        'sortDirection' => ['except' => 'desc'],
    ];

    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function updatingStatusFilter()
    {
        $this->resetPage();
    }

    public function updatingPriorityFilter()
    {
        $this->resetPage();
    }

    public function updatingUserFilter()
    {
        $this->resetPage();
    }

    public function sortBy($field)
    {
        if ($this->sortField === $field) {
            $this->sortDirection = $this->sortDirection === 'asc' ? 'desc' : 'asc';
        } else {
            $this->sortDirection = 'asc';
        }

        $this->sortField = $field;
    }

    public function updateTaskStatus($taskId, $status)
    {
        $task = Task::findOrFail($taskId);
        
        // Check if user can update this task
        if (!auth()->user()->isSuperAdmin() && 
            $task->assigned_to_user_id !== auth()->id() && 
            $task->assigned_by_user_id !== auth()->id()) {
            session()->flash('error', 'You do not have permission to update this task.');
            return;
        }

        $oldStatus = $task->status;
        $task->update(['status' => $status]);

        // Log the status change
        Log::createLog(auth()->id(), 'update_task_status', 
            "Changed task '{$task->title}' status from {$oldStatus} to {$status}");

        session()->flash('success', 'Task status updated successfully.');
    }

    public function deleteTask($taskId)
    {
        $task = Task::findOrFail($taskId);
        
        // Check if user can delete this task
        if (!auth()->user()->isSuperAdmin() && 
            $task->assigned_by_user_id !== auth()->id()) {
            session()->flash('error', 'You do not have permission to delete this task.');
            return;
        }

        // Log the deletion
        Log::createLog(auth()->id(), 'delete_task', "Deleted task: {$task->title}");

        $task->delete();
        
        session()->flash('success', 'Task deleted successfully.');
    }

    public function getTasksProperty()
    {
        $user = auth()->user();
        
        $query = Task::with(['project', 'assignedTo', 'assignedBy'])
            ->when($this->search, function ($query) {
                $query->where('title', 'like', '%' . $this->search . '%')
                      ->orWhere('description', 'like', '%' . $this->search . '%');
            })
            ->when($this->statusFilter, function ($query) {
                $query->where('status', $this->statusFilter);
            })
            ->when($this->priorityFilter, function ($query) {
                $query->where('priority', $this->priorityFilter);
            })
            ->when($this->userFilter, function ($query) {
                $query->where('assigned_to_user_id', $this->userFilter);
            });

        if ($user->isSuperAdmin()) {
            // Super admin can see all tasks
        } elseif ($user->isManager()) {
            $teamMemberIds = $user->teamMembers->pluck('id')->push($user->id);
            $query->whereIn('assigned_to_user_id', $teamMemberIds);
        } else {
            // Employees can only see tasks assigned to them
            $query->where('assigned_to_user_id', $user->id);
        }

        return $query->orderBy($this->sortField, $this->sortDirection)
                    ->paginate(10);
    }

    public function getAvailableUsersProperty()
    {
        $user = auth()->user();
        
        if ($user->isSuperAdmin()) {
            return \App\Models\User::all();
        } elseif ($user->isManager()) {
            return $user->teamMembers;
        } else {
            return collect([$user]);
        }
    }

    public function render()
    {
        return view('livewire.task.task-index')
            ->layout('layouts.app');
    }
}
