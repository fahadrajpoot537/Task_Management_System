<?php

namespace App\Livewire;

use Livewire\Component;

class TaskStatusManager extends Component
{
    public function render()
    {
        return view('livewire.task-status-manager');
    }
}
