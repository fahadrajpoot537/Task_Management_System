<?php

namespace App\Livewire\Dashboard;

use App\Models\Project;
use App\Models\Task;
use App\Models\User;
use Livewire\Component;

class Dashboard extends Component
{
    public $user;
    public $stats = [];

    public function mount()
    {
        $this->user = auth()->user();
        $this->loadStats();
    }

    public function loadStats()
    {
        $user = $this->user;

        if ($user->isSuperAdmin()) {
            $this->stats = [
                'total_projects' => Project::count(),
                'total_tasks' => Task::count(),
                'completed_tasks' => Task::where('status', 'completed')->count(),
                'pending_tasks' => Task::where('status', 'pending')->count(),
                'in_progress_tasks' => Task::where('status', 'in_progress')->count(),
                'overdue_tasks' => Task::where('due_date', '<', now())->where('status', '!=', 'completed')->count(),
                'total_users' => User::count(),
                'categories' => [
                    'development' => Task::where('category', 'development')->count(),
                    'design' => Task::where('category', 'design')->count(),
                    'testing' => Task::where('category', 'testing')->count(),
                    'documentation' => Task::where('category', 'documentation')->count(),
                    'meeting' => Task::where('category', 'meeting')->count(),
                    'general' => Task::where('category', 'general')->count(),
                ],
                'total_estimated_hours' => Task::sum('estimated_hours') ?? 0,
                'total_actual_hours' => Task::sum('actual_hours') ?? 0,
                'delayed_tasks' => Task::where('status', 'completed')
                    ->whereNotNull('due_date')
                    ->whereNotNull('completed_at')
                    ->whereRaw('DATE(completed_at) > DATE(due_date)')
                    ->count(),
                'early_tasks' => Task::where('status', 'completed')
                    ->whereNotNull('due_date')
                    ->whereNotNull('completed_at')
                    ->whereRaw('DATE(completed_at) < DATE(due_date)')
                    ->count(),
                'on_time_tasks' => Task::where('status', 'completed')
                    ->whereNotNull('due_date')
                    ->whereNotNull('completed_at')
                    ->whereRaw('DATE(completed_at) = DATE(due_date)')
                    ->count(),
            ];
        } elseif ($user->isAdmin()) {
            // Admin can see all projects and tasks but cannot manage permissions
            $this->stats = [
                'total_projects' => Project::count(),
                'total_tasks' => Task::count(),
                'completed_tasks' => Task::where('status', 'completed')->count(),
                'pending_tasks' => Task::where('status', 'pending')->count(),
                'in_progress_tasks' => Task::where('status', 'in_progress')->count(),
                'overdue_tasks' => Task::where('due_date', '<', now())->where('status', '!=', 'completed')->count(),
                'total_users' => User::count(),
                'categories' => [
                    'development' => Task::where('category', 'development')->count(),
                    'design' => Task::where('category', 'design')->count(),
                    'testing' => Task::where('category', 'testing')->count(),
                    'documentation' => Task::where('category', 'documentation')->count(),
                    'meeting' => Task::where('category', 'meeting')->count(),
                    'general' => Task::where('category', 'general')->count(),
                ],
                'total_estimated_hours' => Task::sum('estimated_hours') ?? 0,
                'total_actual_hours' => Task::sum('actual_hours') ?? 0,
                'delayed_tasks' => Task::where('status', 'completed')
                    ->whereNotNull('due_date')
                    ->whereNotNull('completed_at')
                    ->whereRaw('DATE(completed_at) > DATE(due_date)')
                    ->count(),
                'early_tasks' => Task::where('status', 'completed')
                    ->whereNotNull('due_date')
                    ->whereNotNull('completed_at')
                    ->whereRaw('DATE(completed_at) < DATE(due_date)')
                    ->count(),
                'on_time_tasks' => Task::where('status', 'completed')
                    ->whereNotNull('due_date')
                    ->whereNotNull('completed_at')
                    ->whereRaw('DATE(completed_at) = DATE(due_date)')
                    ->count(),
            ];
        } elseif ($user->isManager()) {
            $teamMemberIds = $user->teamMembers->pluck('id')->push($user->id);
            
            $this->stats = [
                'total_projects' => Project::whereIn('created_by_user_id', $teamMemberIds)->count(),
                'total_tasks' => Task::whereIn('assigned_to_user_id', $teamMemberIds)->count(),
                'completed_tasks' => Task::whereIn('assigned_to_user_id', $teamMemberIds)->where('status', 'completed')->count(),
                'pending_tasks' => Task::whereIn('assigned_to_user_id', $teamMemberIds)->where('status', 'pending')->count(),
                'in_progress_tasks' => Task::whereIn('assigned_to_user_id', $teamMemberIds)->where('status', 'in_progress')->count(),
                'overdue_tasks' => Task::whereIn('assigned_to_user_id', $teamMemberIds)->where('due_date', '<', now())->where('status', '!=', 'completed')->count(),
                'team_members' => $user->teamMembers->count(),
                'delayed_tasks' => Task::whereIn('assigned_to_user_id', $teamMemberIds)
                    ->where('status', 'completed')
                    ->whereNotNull('due_date')
                    ->whereNotNull('completed_at')
                    ->whereRaw('DATE(completed_at) > DATE(due_date)')
                    ->count(),
                'early_tasks' => Task::whereIn('assigned_to_user_id', $teamMemberIds)
                    ->where('status', 'completed')
                    ->whereNotNull('due_date')
                    ->whereNotNull('completed_at')
                    ->whereRaw('DATE(completed_at) < DATE(due_date)')
                    ->count(),
                'on_time_tasks' => Task::whereIn('assigned_to_user_id', $teamMemberIds)
                    ->where('status', 'completed')
                    ->whereNotNull('due_date')
                    ->whereNotNull('completed_at')
                    ->whereRaw('DATE(completed_at) = DATE(due_date)')
                    ->count(),
            ];
        } else {
            $this->stats = [
                'total_tasks' => $user->assignedTasks()->count(),
                'completed_tasks' => $user->assignedTasks()->where('status', 'completed')->count(),
                'pending_tasks' => $user->assignedTasks()->where('status', 'pending')->count(),
                'in_progress_tasks' => $user->assignedTasks()->where('status', 'in_progress')->count(),
                'overdue_tasks' => $user->assignedTasks()->where('due_date', '<', now())->where('status', '!=', 'completed')->count(),
                'delayed_tasks' => $user->assignedTasks()
                    ->where('status', 'completed')
                    ->whereNotNull('due_date')
                    ->whereNotNull('completed_at')
                    ->whereRaw('DATE(completed_at) > DATE(due_date)')
                    ->count(),
                'early_tasks' => $user->assignedTasks()
                    ->where('status', 'completed')
                    ->whereNotNull('due_date')
                    ->whereNotNull('completed_at')
                    ->whereRaw('DATE(completed_at) < DATE(due_date)')
                    ->count(),
                'on_time_tasks' => $user->assignedTasks()
                    ->where('status', 'completed')
                    ->whereNotNull('due_date')
                    ->whereNotNull('completed_at')
                    ->whereRaw('DATE(completed_at) = DATE(due_date)')
                    ->count(),
            ];
        }
    }

    public function getRecentTasksProperty()
    {
        $user = $this->user;
        
        if ($user->isSuperAdmin()) {
            return Task::with(['project', 'assignedTo', 'assignedBy'])
                ->latest()
                ->limit(5)
                ->get();
        } elseif ($user->isAdmin()) {
            return Task::with(['project', 'assignedTo', 'assignedBy'])
                ->latest()
                ->limit(5)
                ->get();
        } elseif ($user->isManager()) {
            $teamMemberIds = $user->teamMembers->pluck('id')->push($user->id);
            
            return Task::with(['project', 'assignedTo', 'assignedBy'])
                ->whereIn('assigned_to_user_id', $teamMemberIds)
                ->latest()
                ->limit(5)
                ->get();
        } else {
            return $user->assignedTasks()
                ->with(['project', 'assignedTo', 'assignedBy'])
                ->latest()
                ->limit(5)
                ->get();
        }
    }

    public function getRecentProjectsProperty()
    {
        $user = $this->user;
        
        if ($user->isSuperAdmin()) {
            return Project::with('createdBy')->latest()->limit(5)->get();
        } elseif ($user->isAdmin()) {
            return Project::with('createdBy')->latest()->limit(5)->get();
        } elseif ($user->isManager()) {
            $teamMemberIds = $user->teamMembers->pluck('id')->push($user->id);
            
            return Project::with('createdBy')
                ->whereIn('created_by_user_id', $teamMemberIds)
                ->latest()
                ->limit(5)
                ->get();
        } else {
            return Project::with('createdBy')
                ->where('created_by_user_id', $user->id)
                ->latest()
                ->limit(5)
                ->get();
        }
    }

    public function render()
    {
        return view('livewire.dashboard.dashboard')
            ->layout('layouts.app');
    }
}
