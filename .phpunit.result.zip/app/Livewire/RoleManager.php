<?php

namespace App\Livewire;

use Livewire\Component;

class RoleManager extends Component
{
    public function render()
    {
        return view('livewire.role-manager');
    }
}
