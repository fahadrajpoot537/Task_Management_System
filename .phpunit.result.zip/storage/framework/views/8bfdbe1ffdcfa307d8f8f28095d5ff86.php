<div>
    <div class="row mb-4">
        <div class="col-12">
            <h2 class="mb-0">Welcome back, <?php echo e($user->name); ?>!</h2>
            <p class="text-muted">Here's what's happening with your tasks today.</p>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <!--[if BLOCK]><![endif]--><?php if($user->isSuperAdmin()): ?>
            <div class="col-md-3 mb-3">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="bi bi-folder text-primary fs-1"></i>
                        <h5 class="card-title mt-2"><?php echo e($stats['total_projects']); ?></h5>
                        <p class="card-text text-muted">Total Projects</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="bi bi-people text-success fs-1"></i>
                        <h5 class="card-title mt-2"><?php echo e($stats['total_users']); ?></h5>
                        <p class="card-text text-muted">Total Users</p>
                    </div>
                </div>
            </div>
        <?php elseif($user->isManager()): ?>
            <div class="col-md-3 mb-3">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="bi bi-folder text-primary fs-1"></i>
                        <h5 class="card-title mt-2"><?php echo e($stats['total_projects']); ?></h5>
                        <p class="card-text text-muted">Team Projects</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="bi bi-people text-info fs-1"></i>
                        <h5 class="card-title mt-2"><?php echo e($stats['team_members']); ?></h5>
                        <p class="card-text text-muted">Team Members</p>
                    </div>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <div class="col-md-3 mb-3">
            <div class="card text-center">
                <div class="card-body">
                    <i class="bi bi-list-task text-warning fs-1"></i>
                    <h5 class="card-title mt-2"><?php echo e($stats['total_tasks']); ?></h5>
                    <p class="card-text text-muted">Total Tasks</p>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card text-center">
                <div class="card-body">
                    <i class="bi bi-check-circle text-success fs-1"></i>
                    <h5 class="card-title mt-2"><?php echo e($stats['completed_tasks']); ?></h5>
                    <p class="card-text text-muted">Completed</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Task Status Overview -->
    <div class="row mb-4">
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title text-muted">Pending Tasks</h6>
                            <h4 class="text-secondary"><?php echo e($stats['pending_tasks']); ?></h4>
                        </div>
                        <i class="bi bi-clock text-secondary fs-1"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title text-muted">In Progress</h6>
                            <h4 class="text-primary"><?php echo e($stats['in_progress_tasks']); ?></h4>
                        </div>
                        <i class="bi bi-arrow-repeat text-primary fs-1"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title text-muted">Overdue Tasks</h6>
                            <h4 class="text-danger"><?php echo e($stats['overdue_tasks']); ?></h4>
                        </div>
                        <i class="bi bi-exclamation-triangle text-danger fs-1"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Task Performance Statistics -->
    <!--[if BLOCK]><![endif]--><?php if(isset($stats['delayed_tasks']) || isset($stats['early_tasks']) || isset($stats['on_time_tasks'])): ?>
    <div class="row mb-4">
        <div class="col-12">
            <h5 class="mb-3">Task Performance</h5>
        </div>
        <?php if(isset($stats['delayed_tasks'])): ?>
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title text-muted">Delayed Tasks</h6>
                            <h4 class="text-danger"><?php echo e($stats['delayed_tasks']); ?></h4>
                        </div>
                        <i class="bi bi-clock-history text-danger fs-1"></i>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <!--[if BLOCK]><![endif]--><?php if(isset($stats['early_tasks'])): ?>
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title text-muted">Early Completion</h6>
                            <h4 class="text-success"><?php echo e($stats['early_tasks']); ?></h4>
                        </div>
                        <i class="bi bi-lightning text-success fs-1"></i>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <!--[if BLOCK]><![endif]--><?php if(isset($stats['on_time_tasks'])): ?>
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title text-muted">On Time</h6>
                            <h4 class="text-primary"><?php echo e($stats['on_time_tasks']); ?></h4>
                        </div>
                        <i class="bi bi-check-circle-fill text-primary fs-1"></i>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Recent Projects -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Recent Projects</h5>
                    <a href="<?php echo e(route('projects.index')); ?>" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body">
                    <!--[if BLOCK]><![endif]--><?php if($this->recentProjects->count() > 0): ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->recentProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <div>
                                    <h6 class="mb-1"><?php echo e($project->title); ?></h6>
                                    <small class="text-muted"><?php echo e($project->createdBy->name); ?></small>
                                </div>
                                <div class="text-end">
                                    <div class="progress" style="width: 60px; height: 8px;">
                                        <div class="progress-bar" role="progressbar" 
                                             style="width: <?php echo e($project->progress_percentage); ?>%"></div>
                                    </div>
                                    <small class="text-muted"><?php echo e($project->progress_percentage); ?>%</small>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php else: ?>
                        <p class="text-muted text-center">No recent projects found.</p>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Tasks -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Recent Tasks</h5>
                    <a href="<?php echo e(route('tasks.index')); ?>" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body">
                    <!--[if BLOCK]><![endif]--><?php if($this->recentTasks->count() > 0): ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->recentTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <div>
                                    <h6 class="mb-1"><?php echo e($task->title); ?></h6>
                                    <small class="text-muted"><?php echo e($task->project->title); ?></small>
                                </div>
                                <div class="text-end">
                                    <span class="badge <?php echo e($task->status_badge_class); ?>"><?php echo e(ucfirst($task->status)); ?></span>
                                    <br>
                                    <small class="text-muted"><?php echo e($task->assignedTo->name); ?></small>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php else: ?>
                        <p class="text-muted text-center">No recent tasks found.</p>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\myapp\resources\views/livewire/dashboard/dashboard.blade.php ENDPATH**/ ?>