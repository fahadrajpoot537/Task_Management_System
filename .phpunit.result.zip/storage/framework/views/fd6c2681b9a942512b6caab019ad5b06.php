<div>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2>User Permissions</h2>
            <p class="text-muted mb-0">Managing permissions for: <strong><?php echo e($user->name); ?></strong> (<?php echo e($user->email); ?>)</p>
        </div>
        <div>
            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left me-2"></i>Back to Users
            </a>
        </div>
    </div>

    <!-- User Info Card -->
    <div class="card mb-4">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <h5>User Information</h5>
                    <p><strong>Name:</strong> <?php echo e($user->name); ?></p>
                    <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
                    <p><strong>Role:</strong> 
                        <span class="badge bg-info"><?php echo e(ucfirst(str_replace('_', ' ', $user->role->name))); ?></span>
                    </p>
                </div>
                <div class="col-md-6">
                    <h5>Permission Summary</h5>
                    <p><strong>Role Permissions:</strong> <?php echo e($this->userRolePermissions->count()); ?></p>
                    <p><strong>Custom Permissions:</strong> <?php echo e($this->userCustomPermissions->count()); ?></p>
                    <p><strong>Total Permissions:</strong> <?php echo e($this->userRolePermissions->count() + $this->userCustomPermissions->count()); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">Quick Actions</h5>
        </div>
        <div class="card-body">
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-warning" wire:click="resetToRolePermissions" 
                        onclick="return confirm('Reset user permissions to role defaults?')">
                    <i class="bi bi-arrow-clockwise me-2"></i>Reset to Role Defaults
                </button>
                <button type="button" class="btn btn-danger" wire:click="clearAllCustomPermissions" 
                        onclick="return confirm('Clear all custom permissions? This will remove all permissions except role defaults.')">
                    <i class="bi bi-x-circle me-2"></i>Clear Custom Permissions
                </button>
            </div>
        </div>
    </div>

    <!-- Search -->
    <div class="card mb-4">
        <div class="card-body">
            <div class="input-group">
                <span class="input-group-text"><i class="bi bi-search"></i></span>
                <input type="text" class="form-control" placeholder="Search permissions..." 
                       wire:model.live="search">
            </div>
        </div>
    </div>

    <!-- Permissions Table -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">Available Permissions</h5>
        </div>
        <div class="card-body">
            <!--[if BLOCK]><![endif]--><?php if($allPermissions->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th width="50">Status</th>
                                <th>Permission</th>
                                <th>Description</th>
                                <th>Source</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $allPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $hasRolePermission = $this->userRolePermissions->contains('id', $permission->id);
                                    $hasCustomPermission = in_array($permission->id, $userPermissions);
                                    $isEnabled = $hasRolePermission || $hasCustomPermission;
                                ?>
                                <tr class="<?php echo e($isEnabled ? 'table-success' : ''); ?>">
                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if($hasRolePermission): ?>
                                            <span class="badge bg-primary" title="From Role">R</span>
                                        <?php elseif($hasCustomPermission): ?>
                                            <span class="badge bg-warning" title="Custom Permission">C</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary" title="Not Assigned">-</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                    <td>
                                        <strong><?php echo e($permission->name); ?></strong>
                                    </td>
                                    <td><?php echo e($permission->description ?? 'No description available'); ?></td>
                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if($hasRolePermission): ?>
                                            <span class="text-primary">Role: <?php echo e(ucfirst(str_replace('_', ' ', $user->role->name))); ?></span>
                                        <?php elseif($hasCustomPermission): ?>
                                            <span class="text-warning">Custom</span>
                                        <?php else: ?>
                                            <span class="text-muted">Not assigned</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if($hasRolePermission): ?>
                                            <span class="text-muted">Cannot modify (from role)</span>
                                        <?php else: ?>
                                            <button type="button" 
                                                    class="btn btn-sm <?php echo e($hasCustomPermission ? 'btn-outline-danger' : 'btn-outline-success'); ?>"
                                                    wire:click="togglePermission(<?php echo e($permission->id); ?>)">
                                                <!--[if BLOCK]><![endif]--><?php if($hasCustomPermission): ?>
                                                    <i class="bi bi-x-circle me-1"></i>Remove
                                                <?php else: ?>
                                                    <i class="bi bi-plus-circle me-1"></i>Add
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </button>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="bi bi-shield-check text-muted" style="font-size: 3rem;"></i>
                    <h5 class="text-muted mt-3">No permissions found</h5>
                    <p class="text-muted">No permissions match your current search.</p>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

    <!-- Legend -->
    <div class="card mt-4">
        <div class="card-body">
            <h6>Legend:</h6>
            <div class="d-flex gap-3">
                <span class="badge bg-primary">R</span> <small>Permission from Role</small>
                <span class="badge bg-warning">C</span> <small>Custom Permission</small>
                <span class="badge bg-secondary">-</span> <small>Not Assigned</small>
            </div>
            <div class="mt-2">
                <small class="text-muted">
                    <strong>Note:</strong> Role permissions cannot be modified individually. 
                    To change role permissions, modify the role itself in the Permissions section.
                </small>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\myapp\resources\views/livewire/user/user-permission-manager.blade.php ENDPATH**/ ?>