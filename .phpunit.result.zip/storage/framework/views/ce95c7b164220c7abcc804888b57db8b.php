<div>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Team Management</h2>
        <div class="text-muted">
            <i class="bi bi-people me-2"></i>
            Assign employees to managers
        </div>
    </div>

    <!-- Search and Filters -->
    <div class="card mb-4">
        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-search"></i></span>
                        <input type="text" class="form-control" placeholder="Search users..." 
                               wire:model.live="search">
                    </div>
                </div>
                <div class="col-md-3">
                    <select class="form-select" wire:model.live="roleFilter">
                        <option value="">All Roles</option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->name); ?>"><?php echo e(ucfirst(str_replace('_', ' ', $role->name))); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                </div>
                <div class="col-md-3">
                    <select class="form-select" wire:model.live="managerFilter">
                        <option value="">All Managers</option>
                        <option value="unassigned">Unassigned</option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($manager->id); ?>"><?php echo e($manager->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                </div>
            </div>
        </div>
    </div>

    <!-- Users Table -->
    <div class="card">
        <div class="card-body">
            <!--[if BLOCK]><![endif]--><?php if($this->users->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Current Manager</th>
                                <th>Team Members</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-sm bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-2">
                                                <?php echo e(substr($user->name, 0, 1)); ?>

                                            </div>
                                            <strong><?php echo e($user->name); ?></strong>
                                        </div>
                                    </td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td>
                                        <span class="badge bg-info">
                                            <?php echo e(ucfirst(str_replace('_', ' ', $user->role->name))); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if($user->manager): ?>
                                            <span class="badge bg-secondary"><?php echo e($user->manager->name); ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">No manager assigned</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if($user->teamMembers->count() > 0): ?>
                                            <span class="badge bg-success"><?php echo e($user->teamMembers->count()); ?> members</span>
                                        <?php else: ?>
                                            <span class="text-muted">No team members</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-sm btn-outline-primary dropdown-toggle" 
                                                    type="button" data-bs-toggle="dropdown">
                                                Assign Manager
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li>
                                                    <button class="dropdown-item" 
                                                            wire:click="assignManager(<?php echo e($user->id); ?>, null)">
                                                        <span class="text-muted">No Manager</span>
                                                    </button>
                                                </li>
                                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <button class="dropdown-item" 
                                                                wire:click="assignManager(<?php echo e($user->id); ?>, <?php echo e($manager->id); ?>)">
                                                            <?php echo e($manager->name); ?>

                                                        </button>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <div class="d-flex justify-content-center mt-4">
                    <?php echo e($this->users->links()); ?>

                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="bi bi-people text-muted" style="font-size: 3rem;"></i>
                    <h5 class="text-muted mt-3">No users found</h5>
                    <p class="text-muted">No users match your current filters.</p>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

    <!-- Team Structure Overview -->
    <div class="row mt-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h6 class="mb-0">Team Structure</h6>
                </div>
                <div class="card-body">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-3">
                            <div class="d-flex align-items-center mb-2">
                                <div class="avatar-sm bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-2">
                                    <?php echo e(substr($manager->name, 0, 1)); ?>

                                </div>
                                <strong><?php echo e($manager->name); ?></strong>
                                <span class="badge bg-primary ms-2">Manager</span>
                            </div>
                            <!--[if BLOCK]><![endif]--><?php if($manager->teamMembers->count() > 0): ?>
                                <div class="ms-4">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $manager->teamMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="d-flex align-items-center mb-1">
                                            <div class="avatar-sm bg-secondary text-white rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 24px; height: 24px; font-size: 0.75rem;">
                                                <?php echo e(substr($member->name, 0, 1)); ?>

                                            </div>
                                            <small><?php echo e($member->name); ?></small>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            <?php else: ?>
                                <div class="ms-4 text-muted">
                                    <small>No team members assigned</small>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h6 class="mb-0">Unassigned Employees</h6>
                </div>
                <div class="card-body">
                    <?php
                        $unassignedEmployees = $this->users->where('manager_id', null)->where('role.name', 'employee');
                    ?>
                    
                    <!--[if BLOCK]><![endif]--><?php if($unassignedEmployees->count() > 0): ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $unassignedEmployees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex align-items-center mb-2">
                                <div class="avatar-sm bg-warning text-white rounded-circle d-flex align-items-center justify-content-center me-2">
                                    <?php echo e(substr($employee->name, 0, 1)); ?>

                                </div>
                                <span><?php echo e($employee->name); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php else: ?>
                        <p class="text-muted text-center">All employees are assigned to managers.</p>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>
    </div>

    <style>
        .avatar-sm {
            width: 32px;
            height: 32px;
            font-size: 0.875rem;
        }
    </style>
</div>
<?php /**PATH C:\xampp\htdocs\myapp\resources\views/livewire/team/team-manager.blade.php ENDPATH**/ ?>