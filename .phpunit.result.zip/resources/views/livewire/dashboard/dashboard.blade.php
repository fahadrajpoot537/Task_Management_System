<div>
    <div class="row mb-4">
        <div class="col-12">
            <h2 class="mb-0">Welcome back, {{ $user->name }}!</h2>
            <p class="text-muted">Here's what's happening with your tasks today.</p>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        @if($user->isSuperAdmin())
            <div class="col-md-3 mb-3">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="bi bi-folder text-primary fs-1"></i>
                        <h5 class="card-title mt-2">{{ $stats['total_projects'] }}</h5>
                        <p class="card-text text-muted">Total Projects</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="bi bi-people text-success fs-1"></i>
                        <h5 class="card-title mt-2">{{ $stats['total_users'] }}</h5>
                        <p class="card-text text-muted">Total Users</p>
                    </div>
                </div>
            </div>
        @elseif($user->isManager())
            <div class="col-md-3 mb-3">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="bi bi-folder text-primary fs-1"></i>
                        <h5 class="card-title mt-2">{{ $stats['total_projects'] }}</h5>
                        <p class="card-text text-muted">Team Projects</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="bi bi-people text-info fs-1"></i>
                        <h5 class="card-title mt-2">{{ $stats['team_members'] }}</h5>
                        <p class="card-text text-muted">Team Members</p>
                    </div>
                </div>
            </div>
        @endif

        <div class="col-md-3 mb-3">
            <div class="card text-center">
                <div class="card-body">
                    <i class="bi bi-list-task text-warning fs-1"></i>
                    <h5 class="card-title mt-2">{{ $stats['total_tasks'] }}</h5>
                    <p class="card-text text-muted">Total Tasks</p>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card text-center">
                <div class="card-body">
                    <i class="bi bi-check-circle text-success fs-1"></i>
                    <h5 class="card-title mt-2">{{ $stats['completed_tasks'] }}</h5>
                    <p class="card-text text-muted">Completed</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Task Status Overview -->
    <div class="row mb-4">
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title text-muted">Pending Tasks</h6>
                            <h4 class="text-secondary">{{ $stats['pending_tasks'] }}</h4>
                        </div>
                        <i class="bi bi-clock text-secondary fs-1"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title text-muted">In Progress</h6>
                            <h4 class="text-primary">{{ $stats['in_progress_tasks'] }}</h4>
                        </div>
                        <i class="bi bi-arrow-repeat text-primary fs-1"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title text-muted">Overdue Tasks</h6>
                            <h4 class="text-danger">{{ $stats['overdue_tasks'] }}</h4>
                        </div>
                        <i class="bi bi-exclamation-triangle text-danger fs-1"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Task Performance Statistics -->
    @if(isset($stats['delayed_tasks']) || isset($stats['early_tasks']) || isset($stats['on_time_tasks']))
    <div class="row mb-4">
        <div class="col-12">
            <h5 class="mb-3">Task Performance</h5>
        </div>
        @if(isset($stats['delayed_tasks']))
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title text-muted">Delayed Tasks</h6>
                            <h4 class="text-danger">{{ $stats['delayed_tasks'] }}</h4>
                        </div>
                        <i class="bi bi-clock-history text-danger fs-1"></i>
                    </div>
                </div>
            </div>
        </div>
        @endif
        @if(isset($stats['early_tasks']))
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title text-muted">Early Completion</h6>
                            <h4 class="text-success">{{ $stats['early_tasks'] }}</h4>
                        </div>
                        <i class="bi bi-lightning text-success fs-1"></i>
                    </div>
                </div>
            </div>
        </div>
        @endif
        @if(isset($stats['on_time_tasks']))
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title text-muted">On Time</h6>
                            <h4 class="text-primary">{{ $stats['on_time_tasks'] }}</h4>
                        </div>
                        <i class="bi bi-check-circle-fill text-primary fs-1"></i>
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div>
    @endif

    <!-- Recent Projects -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Recent Projects</h5>
                    <a href="{{ route('projects.index') }}" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body">
                    @if($this->recentProjects->count() > 0)
                        @foreach($this->recentProjects as $project)
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <div>
                                    <h6 class="mb-1">{{ $project->title }}</h6>
                                    <small class="text-muted">{{ $project->createdBy->name }}</small>
                                </div>
                                <div class="text-end">
                                    <div class="progress" style="width: 60px; height: 8px;">
                                        <div class="progress-bar" role="progressbar" 
                                             style="width: {{ $project->progress_percentage }}%"></div>
                                    </div>
                                    <small class="text-muted">{{ $project->progress_percentage }}%</small>
                                </div>
                            </div>
                        @endforeach
                    @else
                        <p class="text-muted text-center">No recent projects found.</p>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Tasks -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Recent Tasks</h5>
                    <a href="{{ route('tasks.index') }}" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body">
                    @if($this->recentTasks->count() > 0)
                        @foreach($this->recentTasks as $task)
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <div>
                                    <h6 class="mb-1">{{ $task->title }}</h6>
                                    <small class="text-muted">{{ $task->project->title }}</small>
                                </div>
                                <div class="text-end">
                                    <span class="badge {{ $task->status_badge_class }}">{{ ucfirst($task->status) }}</span>
                                    <br>
                                    <small class="text-muted">{{ $task->assignedTo->name }}</small>
                                </div>
                            </div>
                        @endforeach
                    @else
                        <p class="text-muted text-center">No recent tasks found.</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
