<div>
    <div class="task-table">
        <!-- Table Header -->
        <div class="table-header">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h3 class="mb-2 text-white fw-bold">
                        <i class="bi bi-kanban me-3"></i>Task Management
                    </h3>
                    <p class="mb-0 text-white-50 fs-6">Create, manage, and track your tasks efficiently</p>
                </div>
                <div class="d-flex gap-3">
                    <button class="btn btn-light btn-lg px-4 py-2" wire:click="startEditing(0)" wire:loading.attr="disabled">
                        <i class="bi bi-plus-circle me-2"></i>Add Task
                        <span wire:loading wire:target="startEditing">
                            <span class="spinner-border spinner-border-sm ms-2"></span>
                        </span>
                    </button>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="p-3 border-bottom">
            <div class="row g-2">
                <div class="col-12 col-md-3">
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-search"></i></span>
                        <input type="text" class="form-control" placeholder="Search tasks..." 
                               wire:model.live="search">
                    </div>
                </div>
                <div class="col-6 col-md-2">
                    <select class="form-select" wire:model.live="projectFilter">
                        <option value="">All Projects</option>
                        @foreach($this->projects as $project)
                            <option value="{{ $project->id }}">{{ $project->title }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-6 col-md-2">
                    <select class="form-select" wire:model.live="statusFilter">
                        <option value="">All Status</option>
                        @foreach($this->statuses as $status)
                            <option value="{{ $status->id }}">{{ $status->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-6 col-md-2">
                    <select class="form-select" wire:model.live="categoryFilter">
                        <option value="">All Categories</option>
                        @foreach($this->categories as $category)
                            <option value="{{ $category->id }}">{{ $category->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-12 col-md-2">
                    <select class="form-select" wire:model.live="assigneeFilter">
                        <option value="">All Assignees</option>
                        @foreach($this->users as $user)
                            <option value="{{ $user->id }}">{{ $user->name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
        </div>

        <!-- Task Table -->
        <div class="table-responsive">
            <table id="tasksTable" class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th width="4%">#</th>
                        <th width="18%">Title</th>
                        <th width="10%">Project</th>
                        <th width="10%">Assignee</th>
                        <th width="6%">Priority</th>
                        <th width="6%">Category</th>
                        <th width="6%">Status</th>
                        <th width="6%">Due Date</th>
                        <th width="6%">Hours</th>
                        <th width="15%">Notes</th>
                        <th width="9%">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @if($this->tasks->count() == 0)
                        <tr>
                            <td colspan="11" class="text-center py-4">
                                <div class="text-muted">
                                    <i class="bi bi-inbox fs-1 d-block mb-3"></i>
                                    <h5>No tasks found</h5>
                                    <p class="mb-0">Start by creating your first task!</p>
                                </div>
                            </td>
                        </tr>
                    @endif
                    
                    <!-- New Task Row -->
                    @if($editingTaskId === 0)
                        <tr class="task-row editing">
                            <td>
                                <i class="bi bi-plus-circle text-success"></i>
                            </td>
                            <td>
                                <input type="text" class="task-input" wire:model="newTaskTitle" 
                                       placeholder="Task title..." wire:keydown.enter="saveTask">
                            </td>
                            <td>
                                <select class="form-select form-select-sm" wire:model="newTaskProjectId">
                                    <option value="">Select Project</option>
                                    @foreach($this->projects as $project)
                                        <option value="{{ $project->id }}">{{ $project->title }}</option>
                                    @endforeach
                                </select>
                            </td>
                            <td>
                                <select class="form-select form-select-sm" wire:model="newTaskAssigneeId">
                                    <option value="">Unassigned</option>
                                    @foreach($this->users as $user)
                                        <option value="{{ $user->id }}">{{ $user->name }}</option>
                                    @endforeach
                                </select>
                            </td>
                            <td>
                                <select class="form-select form-select-sm" wire:model="newTaskPriority">
                                    <option value="">Select Priority</option>
                                    @foreach($this->priorities as $priority)
                                        <option value="{{ $priority->id }}">{{ $priority->name }}</option>
                                    @endforeach
                                </select>
                            </td>
                            <td>
                                <select class="form-select form-select-sm" wire:model="newTaskCategory">
                                    <option value="">Select Category</option>
                                    @foreach($this->categories as $category)
                                        <option value="{{ $category->id }}">{{ $category->name }}</option>
                                    @endforeach
                                </select>
                            </td>
                            <td>
                                <span class="status-badge status-pending">Pending</span>
                            </td>
                            <td>
                                <input type="date" class="form-control form-control-sm" wire:model="newTaskDueDate">
                            </td>
                            <td>
                                <input type="number" class="form-control form-control-sm" wire:model="newTaskEstimatedHours" 
                                       placeholder="Hours" min="0" step="0.5">
                            </td>
                            <td>
                                <button class="btn btn-sm btn-outline-secondary" 
                                        wire:click="openNotesModal(0, 'edit')" 
                                        title="Add Notes">
                                    <i class="bi bi-plus-circle me-1"></i>Add Notes
                                </button>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <button class="btn btn-sm btn-success" wire:click="saveTask">
                                        <i class="bi bi-check"></i>
                                    </button>
                                    <button class="btn btn-sm btn-secondary" wire:click="cancelEditing">
                                        <i class="bi bi-x"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    @endif

                    <!-- Existing Tasks -->
                    @foreach($this->tasks as $task)
                        @if($editingTaskId === $task->id)
                            <!-- Editing Row -->
                            <tr class="task-row editing">
                                <td>{{ $task->id }}</td>
                                <td>
                                    <input type="text" class="task-input" wire:model="newTaskTitle" 
                                           wire:keydown.enter="saveTask">
                                </td>
                                <td>
                                    <select class="form-select form-select-sm" wire:model="newTaskProjectId">
                                        @foreach($this->projects as $project)
                                            <option value="{{ $project->id }}">{{ $project->title }}</option>
                                        @endforeach
                                    </select>
                                </td>
                                <td>
                                    <select class="form-select form-select-sm" wire:model="newTaskAssigneeId">
                                        <option value="">Unassigned</option>
                                        @foreach($this->users as $user)
                                            <option value="{{ $user->id }}">{{ $user->name }}</option>
                                        @endforeach
                                    </select>
                                </td>
                                <td>
                                    <select class="form-select form-select-sm" wire:model="newTaskPriority">
                                        <option value="low">Low</option>
                                        <option value="medium">Medium</option>
                                        <option value="high">High</option>
                                    </select>
                                </td>
                                <td>
                                    <select class="form-select form-select-sm" wire:model="newTaskCategory">
                                        <option value="general">General</option>
                                        <option value="development">Development</option>
                                        <option value="design">Design</option>
                                        <option value="testing">Testing</option>
                                        <option value="documentation">Documentation</option>
                                        <option value="meeting">Meeting</option>
                                    </select>
                                </td>
                                <td>
                                    @if($task->status)
                                        <span class="badge bg-{{ $task->status->color }}">
                                            {{ $task->status->name }}
                                        </span>
                                    @else
                                        <span class="badge bg-secondary">No Status</span>
                                    @endif
                                </td>
                                <td>
                                    <input type="date" class="form-control form-control-sm" wire:model="newTaskDueDate">
                                </td>
                                <td>
                                    <input type="number" class="form-control form-control-sm" wire:model="newTaskEstimatedHours" 
                                           placeholder="Hours" min="0" step="0.5">
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-secondary" 
                                            wire:click="openNotesModal({{ $task->id }}, 'edit')" 
                                            title="Edit Notes">
                                        <i class="bi bi-pencil-square me-1"></i>Edit Notes
                                    </button>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <button class="btn btn-sm btn-success" wire:click="saveTask">
                                            <i class="bi bi-check"></i>
                                        </button>
                                        <button class="btn btn-sm btn-secondary" wire:click="cancelEditing">
                                            <i class="bi bi-x"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        @else
                            <!-- Normal Row -->
                            <tr class="task-row">
                                <td>{{ $task->id }}</td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="me-3">
                                            @if($task->priority === 'high')
                                                <i class="bi bi-exclamation-triangle-fill priority-high fs-5"></i>
                                            @elseif($task->priority === 'medium')
                                                <i class="bi bi-dash-circle-fill priority-medium fs-5"></i>
                                            @else
                                                <i class="bi bi-info-circle-fill priority-low fs-5"></i>
                                            @endif
                                        </div>
                                        <div>
                                            <strong class="fs-6">{{ $task->title }}</strong>
                                            @if($task->description)
                                                <br><small class="text-muted">{{ Str::limit($task->description, 50) }}</small>
                                            @endif
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    @if($task->project)
                                        <span class="badge bg-info">{{ $task->project->title }}</span>
                                    @else
                                        <span class="badge bg-secondary">No Project</span>
                                    @endif
                                </td>
                                <td>
                                    @if($task->assignedTo)
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-sm bg-gradient-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3 shadow-sm">
                                                {{ substr($task->assignedTo->name, 0, 1) }}
                                            </div>
                                            <div>
                                                <div class="fw-semibold">{{ $task->assignedTo->name }}</div>
                                                @if($task->assignedTo->role)
                                                    <small class="text-muted">{{ $task->assignedTo->role->name }}</small>
                                                @endif
                                            </div>
                                        </div>
                                    @else
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-sm bg-light border d-flex align-items-center justify-content-center me-3">
                                                <i class="bi bi-person text-muted"></i>
                                            </div>
                                            <span class="text-muted">Unassigned</span>
                                        </div>
                                    @endif
                                </td>
                                <td>
                                    @if($task->priority)
                                        <span class="badge bg-{{ $task->priority->color ?? 'secondary' }}">
                                            {{ $task->priority->name }}
                                        </span>
                                    @else
                                        <span class="badge bg-secondary">No Priority</span>
                                    @endif
                                </td>
                                <td>
                                    @if($task->category)
                                        <span class="badge bg-{{ $task->category->color ?? 'secondary' }}">
                                            <i class="bi {{ $task->category->icon ?? 'bi-tag' }} me-1"></i>
                                            {{ $task->category->name }}
                                        </span>
                                    @else
                                        <span class="badge bg-secondary">
                                            <i class="bi bi-tag me-1"></i>
                                            No Category
                                        </span>
                                    @endif
                                </td>
                                <td>
                                    <div class="dropdown">
                                        @if($task->status)
                                            <button class="btn btn-sm badge bg-{{ $task->status->color }} dropdown-toggle" 
                                                    type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                {{ $task->status->name }}
                                            </button>
                                        @else
                                            <button class="btn btn-sm badge bg-secondary dropdown-toggle" 
                                                    type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                No Status
                                            </button>
                                        @endif
                                        <ul class="dropdown-menu">
                                            @foreach($this->statuses as $status)
                                                <li>
                                                    <a class="dropdown-item {{ $task->status && $task->status->id === $status->id ? 'active' : '' }}" 
                                                       href="#" wire:click="updateTaskStatus({{ $task->id }}, {{ $status->id }})">
                                                        <span class="badge bg-{{ $status->color }} me-2">{{ $status->name }}</span>
                                                    </a>
                                                </li>
                                            @endforeach
                                        </ul>
                                    </div>
                                </td>
                                <td>
                                    @if($task->due_date)
                                        <div class="d-flex flex-column">
                                            <span class="badge bg-{{ $task->due_date < now() && (!$task->status || $task->status->name !== 'Completed') ? 'danger' : 'secondary' }} mb-1">
                                                {{ $task->due_date->format('M d') }}
                                            </span>
                                            @if($task->status && $task->status->name === 'Completed' && $task->completed_at)
                                                <small class="badge {{ $task->delay_badge_class }}">
                                                    {{ $task->delay_badge_text }}
                                                </small>
                                            @endif
                                        </div>
                                    @else
                                        <span class="text-muted">No due date</span>
                                    @endif
                                </td>
                                <td>
                                    <div class="d-flex flex-column">
                                        @if($task->estimated_hours)
                                            <small class="text-muted">Est: {{ $task->estimated_hours }}h</small>
                                        @endif
                                        @if($task->actual_hours)
                                            <small class="text-primary">Act: {{ $task->actual_hours }}h</small>
                                        @endif
                                        @if(!$task->estimated_hours && !$task->actual_hours)
                                            <span class="text-muted">-</span>
                                        @endif
                                    </div>
                                </td>
                                <td>
                                    <div class="notes-container">
                                        @if($task->notes)
                                            <div class="notes-preview" style="max-height: 40px; overflow: hidden; font-size: 0.8rem; color: #6c757d; cursor: pointer;" 
                                                 wire:click="openNotesModal({{ $task->id }}, 'view')" 
                                                 title="Click to view notes">
                                                {{ Str::limit($task->notes, 80) }}
                                            </div>
                                            <button class="btn btn-sm btn-outline-info mt-1" 
                                                    wire:click="openNotesModal({{ $task->id }}, 'edit')" 
                                                    title="Edit Notes">
                                                <i class="bi bi-pencil-square"></i>
                                            </button>
                                        @else
                                            <button class="btn btn-sm btn-outline-secondary" 
                                                    wire:click="openNotesModal({{ $task->id }}, 'edit')" 
                                                    title="Add Notes">
                                                <i class="bi bi-plus-circle me-1"></i>Add Notes
                                            </button>
                                        @endif
                                    </div>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <button class="btn btn-sm btn-outline-primary" wire:click="startEditing({{ $task->id }})" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger" 
                                                onclick="confirmDelete({{ $task->id }})" title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        @endif
                    @endforeach
                </tbody>
            </table>
        </div>

        <!-- Mobile Card Layout -->
       

        <!-- DataTables will handle pagination -->
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirm Delete</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this task? This action cannot be undone.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        let taskIdToDelete = null;

        function confirmDelete(taskId) {
            taskIdToDelete = taskId;
            const modal = new bootstrap.Modal(document.getElementById('deleteModal'));
            modal.show();
        }

        document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
            if (taskIdToDelete) {
                @this.deleteTask(taskIdToDelete);
                const modal = bootstrap.Modal.getInstance(document.getElementById('deleteModal'));
                modal.hide();
            }
        });

        // Fix dropdown positioning to appear above all rows
        document.addEventListener('DOMContentLoaded', function() {
            // Handle dropdown show event
            document.addEventListener('show.bs.dropdown', function(e) {
                const dropdownMenu = e.target.querySelector('.dropdown-menu');
                if (dropdownMenu && e.target.closest('.task-table-container')) {
                    // Set maximum z-index
                    dropdownMenu.style.zIndex = '99999';
                    dropdownMenu.style.position = 'absolute';
                    
                    // Ensure it appears above all table rows
                    setTimeout(() => {
                        dropdownMenu.style.zIndex = '99999';
                        dropdownMenu.style.position = 'absolute';
                    }, 10);
                }
            });
        });

    </script>

    <style>
        .avatar-sm {
            width: 24px;
            height: 24px;
            font-size: 0.75rem;
        }

        /* Status Dropdown Styling */
        .dropdown-toggle::after {
            margin-left: 0.5em;
            font-size: 0.7em;
        }

        .dropdown-menu {
            border: none;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            border-radius: 0.5rem;
            padding: 0.5rem 0;
            z-index: 9999 !important;
            position: absolute !important;
        }

        .dropdown-item {
            padding: 0.5rem 1rem;
            font-size: 0.875rem;
            transition: all 0.2s ease;
        }

        .dropdown-item:hover {
            background-color: #f8f9fa;
            color: #495057;
        }

        .dropdown-item.active {
            background-color: #007bff;
            color: white;
        }

        .dropdown-item i {
            width: 16px;
            text-align: center;
        }

        /* Fix dropdown z-index issues */
        .dropdown {
            position: relative;
            z-index: 1000;
        }

        .table-responsive {
            overflow: visible !important;
        }

        .task-table {
            overflow: visible !important;
        }

        .task-table .table {
            overflow: visible !important;
        }

        .task-table .table td {
            position: relative;
            z-index: 1;
        }
    </style>

    <script>
        // Initialize DataTable when Livewire updates
        document.addEventListener('livewire:updated', function () {
            if ($.fn.DataTable.isDataTable('#tasksTable')) {
                $('#tasksTable').DataTable().destroy();
            }
            
            $('#tasksTable').DataTable({
                responsive: true,
                pageLength: 15,
                lengthMenu: [[10, 15, 25, 50, -1], [10, 15, 25, 50, "All"]],
                order: [[0, 'desc']],
                columnDefs: [
                    { orderable: false, targets: [9] }, // Actions column
                    { className: "text-center", targets: [0, 4, 5, 6, 7, 8, 9] }, // Center align certain columns
                ],
                language: {
                    search: "Search tasks:",
                    lengthMenu: "Show _MENU_ tasks per page",
                    info: "Showing _START_ to _END_ of _TOTAL_ tasks",
                    paginate: {
                        first: "First",
                        last: "Last",
                        next: "Next",
                        previous: "Previous"
                    }
                },
                dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>' +
                     '<"row"<"col-sm-12"tr>>' +
                     '<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7"p>>',
            });
        });

        // Initialize DataTable on page load
        document.addEventListener('DOMContentLoaded', function () {
            setTimeout(function() {
                if ($.fn.DataTable.isDataTable('#tasksTable')) {
                    $('#tasksTable').DataTable().destroy();
                }
                
                $('#tasksTable').DataTable({
                    responsive: true,
                    pageLength: 15,
                    lengthMenu: [[10, 15, 25, 50, -1], [10, 15, 25, 50, "All"]],
                    order: [[0, 'desc']],
                    columnDefs: [
                        { orderable: false, targets: [9] }, // Actions column
                        { className: "text-center", targets: [0, 4, 5, 6, 7, 8, 9] }, // Center align certain columns
                    ],
                    language: {
                        search: "Search tasks:",
                        lengthMenu: "Show _MENU_ tasks per page",
                        info: "Showing _START_ to _END_ of _TOTAL_ tasks",
                        paginate: {
                            first: "First",
                            last: "Last",
                            next: "Next",
                            previous: "Previous"
                        }
                    },
                    dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>' +
                         '<"row"<"col-sm-12"tr>>' +
                         '<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7"p>>',
                });
            }, 100);
        });
    </script>

    <!-- Notes Modal -->
    @if($showNotesModal)
    <div class="modal fade show" style="display: block;" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="bi bi-sticky me-2"></i>{{ $notesModalTitle }}
                    </h5>
                    <button type="button" class="btn-close" wire:click="closeNotesModal"></button>
                </div>
                <div class="modal-body">
                    @if($notesModalMode === 'edit')
                        <div class="mb-3">
                            <label for="notesContent" class="form-label">Notes</label>
                            <textarea class="form-control" 
                                      id="notesContent"
                                      wire:model="notesModalContent" 
                                      rows="8" 
                                      placeholder="Enter your notes here..."></textarea>
                        </div>
                    @else
                        <div class="notes-view">
                            @if($notesModalContent)
                                <div class="notes-content" style="white-space: pre-wrap; line-height: 1.6; font-size: 0.95rem;">
                                    {{ $notesModalContent }}
                                </div>
                            @else
                                <div class="text-muted text-center py-4">
                                    <i class="bi bi-sticky fs-1 d-block mb-3"></i>
                                    <p>No notes available for this task.</p>
                                </div>
                            @endif
                        </div>
                    @endif
                </div>
                <div class="modal-footer">
                    @if($notesModalMode === 'edit')
                        <button type="button" class="btn btn-secondary" wire:click="closeNotesModal">
                            <i class="bi bi-x-circle me-1"></i>Cancel
                        </button>
                        <button type="button" class="btn btn-primary" wire:click="saveNotes">
                            <i class="bi bi-check-circle me-1"></i>Save Notes
                        </button>
                    @else
                        <button type="button" class="btn btn-secondary" wire:click="closeNotesModal">
                            <i class="bi bi-x-circle me-1"></i>Close
                        </button>
                        <button type="button" class="btn btn-primary" wire:click="openNotesModal({{ $notesModalTaskId }}, 'edit')">
                            <i class="bi bi-pencil-square me-1"></i>Edit Notes
                        </button>
                    @endif
                </div>
            </div>
        </div>
    </div>
    <div class="modal-backdrop fade show"></div>
    @endif
</div>
