<?php

namespace Database\Seeders;

use App\Models\TaskPriority;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class TaskPrioritySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $priorities = [
            ['name' => 'Low', 'color' => 'success'],
            ['name' => 'Medium', 'color' => 'warning'],
            ['name' => 'High', 'color' => 'danger'],
        ];

        foreach ($priorities as $priority) {
            TaskPriority::create($priority);
        }
    }
}
