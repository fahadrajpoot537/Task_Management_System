<?php

namespace Database\Seeders;

use App\Models\TaskCategory;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class TaskCategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $categories = [
            ['name' => 'Development', 'icon' => 'bi-code-slash', 'color' => 'primary'],
            ['name' => 'Design', 'icon' => 'bi-palette', 'color' => 'info'],
            ['name' => 'Testing', 'icon' => 'bi-bug', 'color' => 'warning'],
            ['name' => 'Documentation', 'icon' => 'bi-file-text', 'color' => 'success'],
            ['name' => 'Meeting', 'icon' => 'bi-people', 'color' => 'dark'],
            ['name' => 'General', 'icon' => 'bi-list-task', 'color' => 'secondary'],
        ];

        foreach ($categories as $category) {
            TaskCategory::create($category);
        }
    }
}
