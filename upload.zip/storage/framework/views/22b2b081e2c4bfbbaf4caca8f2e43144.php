<div>
    <div class="task-table">
        <!-- Table Header -->
        <div class="table-header">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h3 class="mb-2 text-white fw-bold">
                        <i class="bi bi-kanban me-3"></i>Task Management
                    </h3>
                    <p class="mb-0 text-white-50 fs-6">Create, manage, and track your tasks efficiently</p>
                </div>
                <div class="d-flex gap-3">
                    <button class="btn btn-light btn-lg px-4 py-2" wire:click="startEditing(0)" wire:loading.attr="disabled">
                        <i class="bi bi-plus-circle me-2"></i>Add Task
                        <span wire:loading wire:target="startEditing">
                            <span class="spinner-border spinner-border-sm ms-2"></span>
                        </span>
                    </button>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="p-3 border-bottom">
            <div class="row g-2">
                <div class="col-12 col-md-3">
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-search"></i></span>
                        <input type="text" class="form-control" placeholder="Search tasks..." 
                               wire:model.live="search">
                    </div>
                </div>
                <div class="col-6 col-md-2">
                    <select class="form-select" wire:model.live="projectFilter">
                        <option value="">All Projects</option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($project->id); ?>"><?php echo e($project->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                </div>
                <div class="col-6 col-md-2">
                    <select class="form-select" wire:model.live="statusFilter">
                        <option value="">All Status</option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($status->id); ?>"><?php echo e($status->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                </div>
                <div class="col-6 col-md-2">
                    <select class="form-select" wire:model.live="categoryFilter">
                        <option value="">All Categories</option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                </div>
                <div class="col-12 col-md-2">
                    <select class="form-select" wire:model.live="assigneeFilter">
                        <option value="">All Assignees</option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                </div>
            </div>
        </div>

        <!-- Task Table -->
        <div class="table-responsive">
            <table id="tasksTable" class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th width="4%">#</th>
                        <th width="18%">Title</th>
                        <th width="10%">Project</th>
                        <th width="10%">Assignee</th>
                        <th width="6%">Priority</th>
                        <th width="6%">Category</th>
                        <th width="6%">Status</th>
                        <th width="6%">Due Date</th>
                        <th width="6%">Hours</th>
                        <th width="15%">Notes</th>
                        <th width="9%">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php if($this->tasks->count() == 0): ?>
                        <tr>
                            <td colspan="11" class="text-center py-4">
                                <div class="text-muted">
                                    <i class="bi bi-inbox fs-1 d-block mb-3"></i>
                                    <h5>No tasks found</h5>
                                    <p class="mb-0">Start by creating your first task!</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    
                    <!-- New Task Row -->
                    <!--[if BLOCK]><![endif]--><?php if($editingTaskId === 0): ?>
                        <tr class="task-row editing">
                            <td>
                                <i class="bi bi-plus-circle text-success"></i>
                            </td>
                            <td>
                                <input type="text" class="task-input" wire:model="newTaskTitle" 
                                       placeholder="Task title..." wire:keydown.enter="saveTask">
                            </td>
                            <td>
                                <select class="form-select form-select-sm" wire:model="newTaskProjectId">
                                    <option value="">Select Project</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($project->id); ?>"><?php echo e($project->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                            </td>
                            <td>
                                <select class="form-select form-select-sm" wire:model="newTaskAssigneeId">
                                    <option value="">Unassigned</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                            </td>
                            <td>
                                <select class="form-select form-select-sm" wire:model="newTaskPriority">
                                    <option value="">Select Priority</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->priorities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($priority->id); ?>"><?php echo e($priority->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <small class="text-muted">
                                    <a href="#" wire:click="toggleCustomPriorityForm" class="text-decoration-none">
                                        <i class="bi bi-plus-circle"></i> Add Custom Priority
                                    </a>
                                </small>
                            </td>
                            <td>
                                <select class="form-select form-select-sm" wire:model="newTaskCategory">
                                    <option value="">Select Category</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <small class="text-muted">
                                    <a href="#" wire:click="toggleCustomCategoryForm" class="text-decoration-none">
                                        <i class="bi bi-plus-circle"></i> Add Custom Category
                                    </a>
                                </small>
                            </td>
                            <td>
                                <span class="status-badge status-pending">Pending</span>
                            </td>
                            <td>
                                <input type="date" class="form-control form-control-sm" wire:model="newTaskDueDate">
                            </td>
                            <td>
                                <input type="number" class="form-control form-control-sm" wire:model="newTaskEstimatedHours" 
                                       placeholder="Hours" min="0" step="0.5">
                            </td>
                            <td>
                                <button class="btn btn-sm btn-outline-secondary" 
                                        wire:click="openNotesModal(0, 'edit')" 
                                        title="Add Notes">
                                    <i class="bi bi-plus-circle me-1"></i>Add Notes
                                </button>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <button class="btn btn-sm btn-success" wire:click="saveTask">
                                        <i class="bi bi-check"></i>
                                    </button>
                                    <button class="btn btn-sm btn-secondary" wire:click="cancelEditing">
                                        <i class="bi bi-x"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!-- Existing Tasks -->
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!--[if BLOCK]><![endif]--><?php if($editingTaskId === $task->id): ?>
                            <!-- Editing Row -->
                            <tr class="task-row editing">
                                <td><?php echo e($task->id); ?></td>
                                <td>
                                    <input type="text" class="task-input" wire:model="newTaskTitle" 
                                           wire:keydown.enter="saveTask">
                                </td>
                                <td>
                                    <select class="form-select form-select-sm" wire:model="newTaskProjectId">
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($project->id); ?>"><?php echo e($project->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                </td>
                                <td>
                                    <select class="form-select form-select-sm" wire:model="newTaskAssigneeId">
                                        <option value="">Unassigned</option>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                </td>
                                <td>
                                    <select class="form-select form-select-sm" wire:model="newTaskPriority">
                                        <option value="low">Low</option>
                                        <option value="medium">Medium</option>
                                        <option value="high">High</option>
                                    </select>
                                </td>
                                <td>
                                    <select class="form-select form-select-sm" wire:model="newTaskCategory">
                                        <option value="general">General</option>
                                        <option value="development">Development</option>
                                        <option value="design">Design</option>
                                        <option value="testing">Testing</option>
                                        <option value="documentation">Documentation</option>
                                        <option value="meeting">Meeting</option>
                                    </select>
                                </td>
                                <td>
                                    <!--[if BLOCK]><![endif]--><?php if($task->status): ?>
                                        <span class="badge bg-<?php echo e($task->status->color); ?>">
                                            <?php echo e($task->status->name); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">No Status</span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td>
                                    <input type="date" class="form-control form-control-sm" wire:model="newTaskDueDate">
                                </td>
                                <td>
                                    <input type="number" class="form-control form-control-sm" wire:model="newTaskEstimatedHours" 
                                           placeholder="Hours" min="0" step="0.5">
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-secondary" 
                                            wire:click="openNotesModal(<?php echo e($task->id); ?>, 'edit')" 
                                            title="Edit Notes">
                                        <i class="bi bi-pencil-square me-1"></i>Edit Notes
                                    </button>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <button class="btn btn-sm btn-success" wire:click="saveTask">
                                            <i class="bi bi-check"></i>
                                        </button>
                                        <button class="btn btn-sm btn-secondary" wire:click="cancelEditing">
                                            <i class="bi bi-x"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <!-- Normal Row -->
                            <tr class="task-row">
                                <td><?php echo e($task->id); ?></td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="me-3">
                                            <!--[if BLOCK]><![endif]--><?php if($task->priority === 'high'): ?>
                                                <i class="bi bi-exclamation-triangle-fill priority-high fs-5"></i>
                                            <?php elseif($task->priority === 'medium'): ?>
                                                <i class="bi bi-dash-circle-fill priority-medium fs-5"></i>
                                            <?php else: ?>
                                                <i class="bi bi-info-circle-fill priority-low fs-5"></i>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                        <div>
                                            <strong class="fs-6"><?php echo e($task->title); ?></strong>
                                            <!--[if BLOCK]><![endif]--><?php if($task->description): ?>
                                                <br><small class="text-muted"><?php echo e(Str::limit($task->description, 50)); ?></small>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <!--[if BLOCK]><![endif]--><?php if($task->project): ?>
                                        <span class="badge bg-info"><?php echo e($task->project->title); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">No Project</span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td>
                                    <!--[if BLOCK]><![endif]--><?php if($task->assignedTo): ?>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-sm bg-gradient-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3 shadow-sm">
                                                <?php echo e(substr($task->assignedTo->name, 0, 1)); ?>

                                            </div>
                                            <div>
                                                <div class="fw-semibold"><?php echo e($task->assignedTo->name); ?></div>
                                                <!--[if BLOCK]><![endif]--><?php if($task->assignedTo->role): ?>
                                                    <small class="text-muted"><?php echo e($task->assignedTo->role->name); ?></small>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-sm bg-light border d-flex align-items-center justify-content-center me-3">
                                                <i class="bi bi-person text-muted"></i>
                                            </div>
                                            <span class="text-muted">Unassigned</span>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td>
                                    <div class="dropdown">
                                        <!--[if BLOCK]><![endif]--><?php if($task->priority): ?>
                                            <!--[if BLOCK]><![endif]--><?php if(is_object($task->priority)): ?>
                                                <button class="btn btn-sm badge bg-<?php echo e($task->priority->color ?? 'secondary'); ?> dropdown-toggle" 
                                                        type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <?php echo e($task->priority->name); ?>

                                                </button>
                                            <?php else: ?>
                                                <button class="btn btn-sm badge bg-secondary dropdown-toggle" 
                                                        type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <?php echo e(ucfirst($task->priority)); ?>

                                                </button>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php else: ?>
                                            <button class="btn btn-sm badge bg-secondary dropdown-toggle" 
                                                    type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                No Priority
                                            </button>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <ul class="dropdown-menu">
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->priorities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a class="dropdown-item <?php echo e($task->priority && is_object($task->priority) && $task->priority->id === $priority->id ? 'active' : ''); ?>" 
                                                       href="#" wire:click="updateTaskPriority(<?php echo e($task->id); ?>, <?php echo e($priority->id); ?>)">
                                                        <span class="badge bg-<?php echo e($priority->color); ?> me-2"><?php echo e($priority->name); ?></span>
                                                    </a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                            <li><hr class="dropdown-divider"></li>
                                            <li>
                                                <a class="dropdown-item" href="#" wire:click="toggleCustomPriorityForm">
                                                    <i class="bi bi-plus-circle me-2"></i>Add Custom Priority
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                                <td>
                                    <div class="dropdown">
                                        <!--[if BLOCK]><![endif]--><?php if($task->category): ?>
                                            <!--[if BLOCK]><![endif]--><?php if(is_object($task->category)): ?>
                                                <button class="btn btn-sm badge bg-<?php echo e($task->category->color ?? 'secondary'); ?> dropdown-toggle" 
                                                        type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="bi <?php echo e($task->category->icon ?? 'bi-tag'); ?> me-1"></i>
                                                    <?php echo e($task->category->name); ?>

                                                </button>
                                            <?php else: ?>
                                                <button class="btn btn-sm badge bg-secondary dropdown-toggle" 
                                                        type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="bi bi-tag me-1"></i>
                                                    <?php echo e(ucfirst($task->category)); ?>

                                                </button>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php else: ?>
                                            <button class="btn btn-sm badge bg-secondary dropdown-toggle" 
                                                    type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="bi bi-tag me-1"></i>
                                                No Category
                                            </button>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <ul class="dropdown-menu">
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a class="dropdown-item <?php echo e($task->category && is_object($task->category) && $task->category->id === $category->id ? 'active' : ''); ?>" 
                                                       href="#" wire:click="updateTaskCategory(<?php echo e($task->id); ?>, <?php echo e($category->id); ?>)">
                                                        <span class="badge bg-<?php echo e($category->color); ?> me-2">
                                                            <i class="bi <?php echo e($category->icon); ?> me-1"></i>
                                                            <?php echo e($category->name); ?>

                                                        </span>
                                                    </a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                            <li><hr class="dropdown-divider"></li>
                                            <li>
                                                <a class="dropdown-item" href="#" wire:click="toggleCustomCategoryForm">
                                                    <i class="bi bi-plus-circle me-2"></i>Add Custom Category
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                                <td>
                                    <div class="dropdown">
                                        <!--[if BLOCK]><![endif]--><?php if($task->status): ?>
                                            <button class="btn btn-sm badge bg-<?php echo e($task->status->color); ?> dropdown-toggle" 
                                                    type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                <?php echo e($task->status->name); ?>

                                            </button>
                                        <?php else: ?>
                                            <button class="btn btn-sm badge bg-secondary dropdown-toggle" 
                                                    type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                No Status
                                            </button>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <ul class="dropdown-menu">
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <!--[if BLOCK]><![endif]--><?php if(!auth()->user()->isEmployee() || $status->name !== 'Complete'): ?>
                                                    <li>
                                                        <a class="dropdown-item <?php echo e($task->status && $task->status->id === $status->id ? 'active' : ''); ?>" 
                                                           href="#" wire:click="updateTaskStatus(<?php echo e($task->id); ?>, <?php echo e($status->id); ?>)">
                                                            <span class="badge bg-<?php echo e($status->color); ?> me-2"><?php echo e($status->name); ?></span>
                                                        </a>
                                                    </li>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                            <li><hr class="dropdown-divider"></li>
                                            <li>
                                                <a class="dropdown-item" href="#" wire:click="toggleCustomStatusForm">
                                                    <i class="bi bi-plus-circle me-2"></i>Add Custom Status
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                                <td>
                                    <!--[if BLOCK]><![endif]--><?php if($task->due_date): ?>
                                        <div class="d-flex flex-column">
                                            <span class="badge bg-<?php echo e($task->due_date < now() && (!$task->status || !is_object($task->status) || $task->status->name !== 'Complete') ? 'danger' : 'secondary'); ?> mb-1">
                                                <?php echo e($task->due_date->format('M d')); ?>

                                            </span>
                                            <!--[if BLOCK]><![endif]--><?php if($task->status && is_object($task->status) && $task->status->name === 'Complete' && $task->completed_at): ?>
                                                <small class="badge <?php echo e($task->delay_badge_class); ?>">
                                                    <?php echo e($task->delay_badge_text); ?>

                                                </small>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                    <?php else: ?>
                                        <span class="text-muted">No due date</span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td>
                                    <div class="d-flex flex-column">
                                        <!--[if BLOCK]><![endif]--><?php if($task->estimated_hours): ?>
                                            <small class="text-muted">Est: <?php echo e($task->estimated_hours); ?>h</small>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php if($task->actual_hours): ?>
                                            <small class="text-primary">Act: <?php echo e($task->actual_hours); ?>h</small>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php if(!$task->estimated_hours && !$task->actual_hours): ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </td>
                                <td>
                                    <div class="notes-container">
                                        <!--[if BLOCK]><![endif]--><?php if($task->notes): ?>
                                            <div class="notes-preview" style="max-height: 40px; overflow: hidden; font-size: 0.8rem; color: #6c757d; cursor: pointer;" 
                                                 wire:click="openNotesModal(<?php echo e($task->id); ?>, 'view')" 
                                                 title="Click to view notes">
                                                <?php echo e(Str::limit($task->notes, 80)); ?>

                                            </div>
                                            <button class="btn btn-sm btn-outline-info mt-1" 
                                                    wire:click="openNotesModal(<?php echo e($task->id); ?>, 'edit')" 
                                                    title="Edit Notes">
                                                <i class="bi bi-pencil-square"></i>
                                            </button>
                                        <?php else: ?>
                                            <button class="btn btn-sm btn-outline-secondary" 
                                                    wire:click="openNotesModal(<?php echo e($task->id); ?>, 'edit')" 
                                                    title="Add Notes">
                                                <i class="bi bi-plus-circle me-1"></i>Add Notes
                                            </button>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <button class="btn btn-sm btn-outline-primary" wire:click="startEditing(<?php echo e($task->id); ?>)" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger" 
                                                onclick="confirmDelete(<?php echo e($task->id); ?>)" title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>

        <!-- Mobile Card Layout -->
       

        <!-- DataTables will handle pagination -->
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirm Delete</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this task? This action cannot be undone.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        let taskIdToDelete = null;

        function confirmDelete(taskId) {
            taskIdToDelete = taskId;
            const modal = new bootstrap.Modal(document.getElementById('deleteModal'));
            modal.show();
        }

        document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
            if (taskIdToDelete) {
                window.Livewire.find('<?php echo e($_instance->getId()); ?>').deleteTask(taskIdToDelete);
                const modal = bootstrap.Modal.getInstance(document.getElementById('deleteModal'));
                modal.hide();
            }
        });

        // Fix dropdown positioning to appear above all rows
        document.addEventListener('DOMContentLoaded', function() {
            // Handle dropdown show event
            document.addEventListener('show.bs.dropdown', function(e) {
                const dropdownMenu = e.target.querySelector('.dropdown-menu');
                if (dropdownMenu && e.target.closest('.task-table-container')) {
                    // Set maximum z-index
                    dropdownMenu.style.zIndex = '99999';
                    dropdownMenu.style.position = 'absolute';
                    
                    // Ensure it appears above all table rows
                    setTimeout(() => {
                        dropdownMenu.style.zIndex = '99999';
                        dropdownMenu.style.position = 'absolute';
                    }, 10);
                }
            });
        });

    </script>

    <style>
        .avatar-sm {
            width: 24px;
            height: 24px;
            font-size: 0.75rem;
        }

        /* Status Dropdown Styling */
        .dropdown-toggle::after {
            margin-left: 0.5em;
            font-size: 0.7em;
        }

        .dropdown-menu {
            border: none;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            border-radius: 0.5rem;
            padding: 0.5rem 0;
            z-index: 9999 !important;
            position: absolute !important;
        }

        .dropdown-item {
            padding: 0.5rem 1rem;
            font-size: 0.875rem;
            transition: all 0.2s ease;
        }

        .dropdown-item:hover {
            background-color: #f8f9fa;
            color: #495057;
        }

        .dropdown-item.active {
            background-color: #007bff;
            color: white;
        }

        .dropdown-item i {
            width: 16px;
            text-align: center;
        }

        /* Fix dropdown z-index issues */
        .dropdown {
            position: relative;
            z-index: 1000;
        }

        .table-responsive {
            overflow: visible !important;
        }

        .task-table {
            overflow: visible !important;
        }

        .task-table .table {
            overflow: visible !important;
        }

        .task-table .table td {
            position: relative;
            z-index: 1;
        }
    </style>

    <script>
        // Initialize DataTable when Livewire updates
        document.addEventListener('livewire:updated', function () {
            if ($.fn.DataTable.isDataTable('#tasksTable')) {
                $('#tasksTable').DataTable().destroy();
            }
            
            $('#tasksTable').DataTable({
                responsive: true,
                pageLength: 15,
                lengthMenu: [[10, 15, 25, 50, -1], [10, 15, 25, 50, "All"]],
                order: [[0, 'desc']],
                columnDefs: [
                    { orderable: false, targets: [9] }, // Actions column
                    { className: "text-center", targets: [0, 4, 5, 6, 7, 8, 9] }, // Center align certain columns
                ],
                language: {
                    search: "Search tasks:",
                    lengthMenu: "Show _MENU_ tasks per page",
                    info: "Showing _START_ to _END_ of _TOTAL_ tasks",
                    paginate: {
                        first: "First",
                        last: "Last",
                        next: "Next",
                        previous: "Previous"
                    }
                },
                dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>' +
                     '<"row"<"col-sm-12"tr>>' +
                     '<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7"p>>',
            });
        });

        // Initialize DataTable on page load
        document.addEventListener('DOMContentLoaded', function () {
            setTimeout(function() {
                if ($.fn.DataTable.isDataTable('#tasksTable')) {
                    $('#tasksTable').DataTable().destroy();
                }
                
                $('#tasksTable').DataTable({
                    responsive: true,
                    pageLength: 15,
                    lengthMenu: [[10, 15, 25, 50, -1], [10, 15, 25, 50, "All"]],
                    order: [[0, 'desc']],
                    columnDefs: [
                        { orderable: false, targets: [9] }, // Actions column
                        { className: "text-center", targets: [0, 4, 5, 6, 7, 8, 9] }, // Center align certain columns
                    ],
                    language: {
                        search: "Search tasks:",
                        lengthMenu: "Show _MENU_ tasks per page",
                        info: "Showing _START_ to _END_ of _TOTAL_ tasks",
                        paginate: {
                            first: "First",
                            last: "Last",
                            next: "Next",
                            previous: "Previous"
                        }
                    },
                    dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>' +
                         '<"row"<"col-sm-12"tr>>' +
                         '<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7"p>>',
                });
            }, 100);
        });
    </script>

    <!-- Notes Modal -->
    <!--[if BLOCK]><![endif]--><?php if($showNotesModal): ?>
    <div class="modal fade show" style="display: block;" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="bi bi-sticky me-2"></i><?php echo e($notesModalTitle); ?>

                    </h5>
                    <button type="button" class="btn-close" wire:click="closeNotesModal"></button>
                </div>
                <div class="modal-body">
                    <!--[if BLOCK]><![endif]--><?php if($notesModalMode === 'edit'): ?>
                        <div class="mb-3">
                            <label for="notesContent" class="form-label">Notes</label>
                            <textarea class="form-control" 
                                      id="notesContent"
                                      wire:model="notesModalContent" 
                                      rows="8" 
                                      placeholder="Enter your notes here..."></textarea>
                        </div>
                    <?php else: ?>
                        <div class="notes-view">
                            <!--[if BLOCK]><![endif]--><?php if($notesModalContent): ?>
                                <div class="notes-content" style="white-space: pre-wrap; line-height: 1.6; font-size: 0.95rem;">
                                    <?php echo e($notesModalContent); ?>

                                </div>
                            <?php else: ?>
                                <div class="text-muted text-center py-4">
                                    <i class="bi bi-sticky fs-1 d-block mb-3"></i>
                                    <p>No notes available for this task.</p>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                <div class="modal-footer">
                    <!--[if BLOCK]><![endif]--><?php if($notesModalMode === 'edit'): ?>
                        <button type="button" class="btn btn-secondary" wire:click="closeNotesModal">
                            <i class="bi bi-x-circle me-1"></i>Cancel
                        </button>
                        <button type="button" class="btn btn-primary" wire:click="saveNotes">
                            <i class="bi bi-check-circle me-1"></i>Save Notes
                        </button>
                    <?php else: ?>
                        <button type="button" class="btn btn-secondary" wire:click="closeNotesModal">
                            <i class="bi bi-x-circle me-1"></i>Close
                        </button>
                        <button type="button" class="btn btn-primary" wire:click="openNotesModal(<?php echo e($notesModalTaskId); ?>, 'edit')">
                            <i class="bi bi-pencil-square me-1"></i>Edit Notes
                        </button>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>
    </div>
    <div class="modal-backdrop fade show"></div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Custom Status Creation Form -->
    <!--[if BLOCK]><![endif]--><?php if($showCustomStatusForm): ?>
    <div class="modal fade show" style="display: block;" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="bi bi-plus-circle me-2"></i>Add Custom Status
                    </h5>
                    <button type="button" class="btn-close" wire:click="resetCustomStatusForm"></button>
                </div>
                <div class="modal-body">
                    <form wire:submit.prevent="createCustomStatus">
                        <div class="mb-3">
                            <label for="customStatusName" class="form-label">Status Name</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['customStatusName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="customStatusName" wire:model="customStatusName" placeholder="Enter status name">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['customStatusName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="mb-3">
                            <label for="customStatusColor" class="form-label">Color</label>
                            <select class="form-select <?php $__errorArgs = ['customStatusColor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    id="customStatusColor" wire:model="customStatusColor">
                                <option value="primary">Primary (Blue)</option>
                                <option value="secondary">Secondary (Gray)</option>
                                <option value="success">Success (Green)</option>
                                <option value="danger">Danger (Red)</option>
                                <option value="warning">Warning (Yellow)</option>
                                <option value="info">Info (Cyan)</option>
                                <option value="light">Light</option>
                                <option value="dark">Dark</option>
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['customStatusColor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-success">
                                <i class="bi bi-check-circle"></i> Create Status
                            </button>
                            <button type="button" wire:click="resetCustomStatusForm" class="btn btn-secondary">
                                <i class="bi bi-x-circle"></i> Cancel
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal-backdrop fade show"></div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Custom Priority Creation Form -->
    <!--[if BLOCK]><![endif]--><?php if($showCustomPriorityForm): ?>
    <div class="modal fade show" style="display: block;" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="bi bi-plus-circle me-2"></i>Add Custom Priority
                    </h5>
                    <button type="button" class="btn-close" wire:click="resetCustomPriorityForm"></button>
                </div>
                <div class="modal-body">
                    <form wire:submit.prevent="createCustomPriority">
                        <div class="mb-3">
                            <label for="customPriorityName" class="form-label">Priority Name</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['customPriorityName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="customPriorityName" wire:model="customPriorityName" placeholder="Enter priority name">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['customPriorityName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="mb-3">
                            <label for="customPriorityColor" class="form-label">Color</label>
                            <select class="form-select <?php $__errorArgs = ['customPriorityColor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    id="customPriorityColor" wire:model="customPriorityColor">
                                <option value="primary">Primary (Blue)</option>
                                <option value="secondary">Secondary (Gray)</option>
                                <option value="success">Success (Green)</option>
                                <option value="danger">Danger (Red)</option>
                                <option value="warning">Warning (Yellow)</option>
                                <option value="info">Info (Cyan)</option>
                                <option value="light">Light</option>
                                <option value="dark">Dark</option>
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['customPriorityColor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-success">
                                <i class="bi bi-check-circle"></i> Create Priority
                            </button>
                            <button type="button" wire:click="resetCustomPriorityForm" class="btn btn-secondary">
                                <i class="bi bi-x-circle"></i> Cancel
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal-backdrop fade show"></div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Custom Category Creation Form -->
    <!--[if BLOCK]><![endif]--><?php if($showCustomCategoryForm): ?>
    <div class="modal fade show" style="display: block;" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="bi bi-plus-circle me-2"></i>Add Custom Category
                    </h5>
                    <button type="button" class="btn-close" wire:click="resetCustomCategoryForm"></button>
                </div>
                <div class="modal-body">
                    <form wire:submit.prevent="createCustomCategory">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="customCategoryName" class="form-label">Category Name</label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['customCategoryName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="customCategoryName" wire:model="customCategoryName" placeholder="Enter category name">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['customCategoryName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="customCategoryIcon" class="form-label">Icon</label>
                                    <select class="form-select <?php $__errorArgs = ['customCategoryIcon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            id="customCategoryIcon" wire:model="customCategoryIcon">
                                        <option value="bi-list-task">List Task</option>
                                        <option value="bi-code-slash">Code</option>
                                        <option value="bi-palette">Design</option>
                                        <option value="bi-bug">Testing</option>
                                        <option value="bi-file-text">Documentation</option>
                                        <option value="bi-people">Meeting</option>
                                        <option value="bi-calendar">Calendar</option>
                                        <option value="bi-chat">Chat</option>
                                        <option value="bi-graph-up">Analytics</option>
                                        <option value="bi-gear">Settings</option>
                                    </select>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['customCategoryIcon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="customCategoryColor" class="form-label">Color</label>
                            <select class="form-select <?php $__errorArgs = ['customCategoryColor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    id="customCategoryColor" wire:model="customCategoryColor">
                                <option value="primary">Primary (Blue)</option>
                                <option value="secondary">Secondary (Gray)</option>
                                <option value="success">Success (Green)</option>
                                <option value="danger">Danger (Red)</option>
                                <option value="warning">Warning (Yellow)</option>
                                <option value="info">Info (Cyan)</option>
                                <option value="light">Light</option>
                                <option value="dark">Dark</option>
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['customCategoryColor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-success">
                                <i class="bi bi-check-circle"></i> Create Category
                            </button>
                            <button type="button" wire:click="resetCustomCategoryForm" class="btn btn-secondary">
                                <i class="bi bi-x-circle"></i> Cancel
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal-backdrop fade show"></div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\myapp\resources\views/livewire/task/task-table.blade.php ENDPATH**/ ?>