<div>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Manager Management</h2>
        <!--[if BLOCK]><![endif]--><?php if(auth()->user()->isSuperAdmin()): ?>
            <button class="btn btn-primary" wire:click="openForm" wire:loading.attr="disabled">
                <i class="bi bi-person-plus me-2"></i>Add Manager
                <span wire:loading wire:target="openForm">Loading...</span>
            </button>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>


    <!-- Create Manager Form -->
    <!--[if BLOCK]><![endif]--><?php if($showCreateForm): ?>
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Create New Manager</h5>
                <button type="button" class="btn-close" wire:click="hideCreateForm"></button>
            </div>
            <div class="card-body">
                <form wire:submit="createManager">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="name" class="form-label">Full Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="name" wire:model="name" required>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="email" class="form-label">Email Address <span class="text-danger">*</span></label>
                            <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="email" wire:model="email" required>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>

                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="sendInvitation" wire:model="sendInvitation">
                            <label class="form-check-label" for="sendInvitation">
                                Send email invitation with temporary password
                            </label>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-outline-secondary" wire:click="hideCreateForm">
                            Cancel
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-check-circle me-2"></i>Create Manager
                        </button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Search -->
    <div class="card mb-4">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-search"></i></span>
                        <input type="text" class="form-control" placeholder="Search managers..." 
                               wire:model.live="search">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Managers Table -->
    <div class="card">
        <div class="card-body">
            <!--[if BLOCK]><![endif]--><?php if($this->managers->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Team Size</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-sm bg-warning text-white rounded-circle d-flex align-items-center justify-content-center me-2">
                                                <?php echo e(substr($manager->name, 0, 1)); ?>

                                            </div>
                                            <strong><?php echo e($manager->name); ?></strong>
                                        </div>
                                    </td>
                                    <td><?php echo e($manager->email); ?></td>
                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if($manager->teamMembers->count() > 0): ?>
                                            <span class="badge bg-success"><?php echo e($manager->teamMembers->count()); ?> members</span>
                                        <?php else: ?>
                                            <span class="text-muted">No team</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                    <td><?php echo e($manager->created_at->format('M d, Y')); ?></td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('users.permissions', $manager->id)); ?>" 
                                               class="btn btn-sm btn-outline-info" title="Manage Permissions">
                                                <i class="bi bi-shield-check"></i>
                                            </a>
                                            <!--[if BLOCK]><![endif]--><?php if(auth()->user()->isSuperAdmin()): ?>
                                                <button type="button" class="btn btn-sm btn-outline-warning" 
                                                        wire:click="resendInvitation(<?php echo e($manager->id); ?>)"
                                                        title="Resend Invitation">
                                                    <i class="bi bi-envelope"></i>
                                                </button>
                                                <button type="button" class="btn btn-sm btn-outline-danger" 
                                                        onclick="confirmDelete(<?php echo e($manager->id); ?>)"
                                                        title="Delete Manager">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <div class="d-flex justify-content-center mt-4">
                    <?php echo e($this->managers->links()); ?>

                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="bi bi-people text-muted" style="font-size: 3rem;"></i>
                    <h5 class="text-muted mt-3">No managers found</h5>
                    <p class="text-muted">No managers match your current search.</p>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirm Delete</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this manager? This action cannot be undone and will remove all associated data.</p>
                    <div class="alert alert-warning">
                        <strong>Warning:</strong> Make sure this manager has no team members before deleting.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        let managerIdToDelete = null;

        function confirmDelete(managerId) {
            managerIdToDelete = managerId;
            const modal = new bootstrap.Modal(document.getElementById('deleteModal'));
            modal.show();
        }

        document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
            if (managerIdToDelete) {
                window.Livewire.find('<?php echo e($_instance->getId()); ?>').deleteManager(managerIdToDelete);
                const modal = bootstrap.Modal.getInstance(document.getElementById('deleteModal'));
                modal.hide();
            }
        });
    </script>

    <style>
        .avatar-sm {
            width: 32px;
            height: 32px;
            font-size: 0.875rem;
        }
    </style>

</div>
<?php /**PATH C:\xampp\htdocs\myapp\resources\views/livewire/manager/manager-manager.blade.php ENDPATH**/ ?>